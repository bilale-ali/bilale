<?php
// Decoded by Girudatsu.com Member

$lnOBezRu = 'header';
$pdo = new PDO('sqlite:database.db');
$creditcards = $pdo->query('SELECT * FROM `creditcards`')->fetchAll(PDO::FETCH_ASSOC);
@session_start();
if (!isset($_SESSION['login_success'])) {
    @header('Location: ../index.php');
    exit;
}
?>
<div id="title_1">Trojan: <br><center><img width="200px" src="img/roadblock.svg"><br><font color="#D91F2C">[<font color="#FFFFFF">Under Construction!</font>]</font></center></div>
