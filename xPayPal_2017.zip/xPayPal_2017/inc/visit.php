<?php
// Decoded by Girudatsu.com Member

if (isset($_POST['xBrowser']) && isset($_POST['xOperatingSystem'])) {
    $date = date('d/m/Y');
    $time = date('h:i a');
    $ip = getenv('REMOTE_ADDR');
    $xBrowser = $_POST['xBrowser'];
    $xOperatingSystem = $_POST['xOperatingSystem'];
    $xPlatForm = $_POST['xPlatForm'];
    $pdo = new PDO('sqlite:../admin/database.db');
    if ($pdo) {
        $check = $pdo->query('' . 'SELECT * FROM `visitors` WHERE `ip`=\'' . "{$ip}" . '\' AND `date`=\'' . "{$time}" . '\'' . '')->fetchAll(PDO::FETCH_ASSOC);
        if (!$check) {
            $pdo->query('' . 'INSERT INTO `visitors` VALUES (NULL,\'' . "{$ip}" . '\',\'' . "{$xBrowser}" . '\',\'' . "{$xOperatingSystem}" . '\',\'' . "{$xPlatForm}" . '\',\'\',\'\',\'' . "{$date}" . '\',\'' . "{$time}" . '\',\'\',\'\')' . '');
        }
    }
}
