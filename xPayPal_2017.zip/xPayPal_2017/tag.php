<?php 


function opentagchange($file){

	$content = file_get_contents($file);
	$tokens = token_get_all($content);
	$output = '';

	foreach($tokens as $token) {
	 if(is_array($token)) {
		var_dump($token);
	  list($index, $code, $line) = $token;
	  switch($index) {
	   case T_OPEN_TAG:
		$output .= '<?php ';
		break;
	   case T_OPEN_TAG_WITH_ECHO:
		$output .= '<?php echo ';
		break;
	   default:
		$output .= $code;
		break;
	  }

	 }
	 else {
	  $output .= $token;
	 }
	}
	return $output;
	
}



$sourceDir = "admin"; // folder that you want bulk decode. without slash!
$decoded = "/";
$encoded = "enc/";

$di = new RecursiveDirectoryIterator(__DIR__ .'\\'.$sourceDir,RecursiveDirectoryIterator::SKIP_DOTS);
$it = new RecursiveIteratorIterator($di);


foreach($it as $file) {
    if (pathinfo($file, PATHINFO_EXTENSION) == "php") {
        		
					$pc = dirname($file);
					$root = dirname(__FILE__);
					$c = str_replace($root.'\\', '', $pc);
					$c = str_replace('\\','/', $c);
					
					$content = opentagchange($file);
					$decoded_path = $decoded.$c;
					$encoded_path = $encoded.$c;
					if (!file_exists($decoded_path)) {
						@mkdir($decoded_path, 0777, true);
					}
					
					if (!file_exists($encoded_path)) {
						@mkdir($encoded_path, 0777, true);
					}
					
					$file_dec = $decoded_path.'/'.basename($file);
					
					//$fp = fopen ($file_dec, 'w+');
				
					//fclose($fp);
					
					//file_put_contents($file, $content);
					
					
					//rename ($c.'/'.basename($file), $encoded_path.'/'.basename($file));
					echo '$pc : ' . $pc . '<br/>';
					echo '$root : ' . $root . '<br/>';
					echo '$c : ' . $c . '<br/>';
					echo '$decoded_path : ' . $decoded_path . '<br/>';
					echo '$encoded_path : ' . $encoded_path . '<br/>';
					echo '$file_enc : ' . $file . '<br/>';
					echo '$file_dec : ' . $file_dec . '<br/><br/><br/>';
					
    }
}



