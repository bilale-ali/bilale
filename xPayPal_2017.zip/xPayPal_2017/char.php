<?php

$file = 'index.php';

$content = file_get_contents($file);
	$tokens = token_get_all($content);
	$output = '';
var_dump($tokens);
	foreach($tokens as $token) {
	 if(is_array($token)) {
	  list($index, $code, $line) = $token;
	  switch($index) {
	   case T_FUNCTION:
		$output .= $index;
		break;
	   default:
		$output .= $code;
		break;
	  }

	 }
	 else {
	  $output .= $token;
	 }
	}
	echo $output;
	
	
	
//file_put_contents($file_dec, $content);
					